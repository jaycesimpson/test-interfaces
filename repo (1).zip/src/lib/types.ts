// Member Profile Data Types

export type MemberStatus = 'Active' | 'Inactive' | 'Suspended';

export interface EmergencyContact {
  name: string;
  phone: string;
  relationship: string;
}

export interface MemberIdentity {
  id: string;
  avatar: string;
  name: string;
  email: string;
  phone: string;
  dob: string;
  memberSince: string;
  status: MemberStatus;
  tags: string[];
  emergencyContact: EmergencyContact;
  lastEditedBy: string;
  lastEditedAt: string;
}

export interface Demographics {
  address: string;
  occupation: string;
  education: string;
  familyStatus: string;
}

export interface Lifestyle {
  workSchedule: string;
  stressLevel: string;
  travelFrequency: string;
}

export interface MedicalHistory {
  conditions: string[];
  medications: string[];
  allergies: string[];
  surgeries: string[];
}



export interface Profile {
  demographics: Demographics;
  lifestyle: Lifestyle;
  medicalHistory: MedicalHistory;
  goals: string[];
}

export type ProgramStatus = 'in-progress' | 'assignment-needed' | 'needs-review';

export interface ProgramAssignment {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  assignedBy: string;
  status: 'active' | 'completed' | 'upcoming';
  completionRate?: number;
  adherenceScore?: number;
  foodLoggingAdherence?: number;
  lastEditedBy: string;
  lastEditedAt: string;
  alertNote?: string;
}

export interface ProgramChange {
  id: string;
  category: 'medical' | 'performance' | 'nutrition' | 'recovery';
  action: string;
  changedBy: string;
  changedAt: string;
  details: string;
}

export interface ProgramHistory {
  current: ProgramAssignment | null;
  history: ProgramAssignment[];
}

export interface Programming {
  performance: ProgramHistory;
  nutrition: ProgramHistory;
  recovery: ProgramHistory;
  medical: ProgramHistory;
}

export interface LabResult {
  id: string;
  date: string;
  biomarker: string;
  value: number;
  unit: string;
  normalRange: { min: number; max: number };
  status: 'normal' | 'high' | 'low';
}

export interface DexaScan {
  id: string;
  date: string;
  bodyFat: number;
  leanMass: number;
  boneDensity: number;
}

export interface Assessment {
  id: string;
  date: string;
  type: string;
  score: number;
  notes: string;
}

export interface Results {
  labs: LabResult[];
  bodyComp: DexaScan[];
  assessments: Assessment[];
  mentalHealthAssessments: MentalHealthAssessment[];
}

export interface ConnectedDevice {
  id: string;
  name: string;
  type: 'whoop' | 'oura' | 'eight-sleep' | 'apple-watch' | 'garmin';
  connected: boolean;
  lastSync: string;
  battery: number;
}

export interface TimeSeriesDataPoint {
  date: string;
  value: number;
}

export interface WearableMetrics {
  hrv: TimeSeriesDataPoint[];
  sleep: TimeSeriesDataPoint[];
  strain: TimeSeriesDataPoint[];
  recovery: TimeSeriesDataPoint[];
  steps: TimeSeriesDataPoint[];
  heartRate: TimeSeriesDataPoint[];
}

export interface Wearables {
  devices: ConnectedDevice[];
  metrics: WearableMetrics;
  provider: 'Junction';
}

export interface FileItem {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadedAt: string;
  uploadedBy: string;
}

export interface FileCategory {
  category: string;
  files: FileItem[];
}

export interface InternalNote {
  id: string;
  author: string;
  authorAvatar: string;
  content: string;
  mentions: string[];
  createdAt: string;
  pinned: boolean;
}

export interface Alert {
  id: string;
  type: 'warning' | 'info' | 'error';
  message: string;
  createdAt: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  user: string;
  userAvatar: string;
  action: string;
  category: 'member' | 'admin';
  affectedData: string;
  previousValue?: string;
  newValue?: string;
}

// Billing Types
export interface Membership {
  tier: string;
  billingCycle: 'monthly' | 'quarterly' | 'annual';
  rate: number;
  startDate: string;
  pendingEndDate?: string;
  endDate?: string;
  referredBy?: string;
  scheduledChange?: {
    newTier: string;
    newRate: number;
    effectiveDate: string;
  };
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  status: 'completed' | 'pending' | 'failed' | 'refunded';
  type: 'subscription' | 'one-time' | 'refund';
  method: string;
}

export interface PromoCode {
  id: string;
  code: string;
  discount: string;
  appliedDate: string;
  expiresDate?: string;
  status: 'active' | 'expired' | 'used';
}

export interface PaymentMethod {
  type: 'card' | 'bank';
  last4: string;
  brand?: string;
  expiryDate?: string;
}

export interface BillingNote {
  id: string;
  author: string;
  content: string;
  createdAt: string;
  isAlert: boolean;
}

export interface Billing {
  membership: Membership;
  transactions: Transaction[];
  promoCodes: PromoCode[];
  paymentMethod: PaymentMethod;
  billingNotes: BillingNote[];
}

// Connection Types
export interface Connection {
  id: string;
  name: string;
  email: string;
  relationship: string;
  addedDate: string;
  status: 'active' | 'pending' | 'inactive';
}

// Security Types
export interface SecurityInfo {
  email: string;
  phone: string;
  googleLinked: boolean;
  appleLinked: boolean;
  lastPasswordChange: string;
  twoFactorEnabled: boolean;
}

// Lab Order Types
export interface LabOrder {
  id: string;
  orderDate: string;
  status: 'ordered' | 'kit-shipped' | 'sample-received' | 'processing' | 'results-ready' | 'completed';
  type: 'bundle' | 'custom';
  bundleName?: string;
  biomarkers: string[];
  drawMethod: 'veyda-phlebotomist' | 'provider-facility';
  dueDate: string;
  instructions?: string;
  customFee?: number;
  orderedBy: string;
  trackingInfo?: {
    kitShipped?: string;
    sampleReceived?: string;
    resultsReady?: string;
  };
  results?: LabResult[];
}

// Supplement Order Types (Fullscript API)
export interface SupplementItem {
  id: string;
  name: string;
  dosage: string;
  instructions: string;
}

export interface SupplementOrder {
  id: string;
  orderDate: string;
  status: 'active' | 'completed' | 'cancelled';
  type: 'bundle' | 'custom';
  bundleName?: string;
  supplements: SupplementItem[];
  startDate: string;
  endDate: string;
  discountPercent: number;
  planNotes?: string;
  orderedBy: string;
}

// Assessment Types
export interface MentalHealthAssessment {
  id: string;
  date: string;
  type: 'PHQ-9' | 'GAD-7' | 'WHO-5' | 'ISI';
  score: number;
  interpretation: string;
  notes?: string;
}

// Care Team Types
export interface CareTeamMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  specialty?: string;
}

export interface CareTeam {
  coordinator: CareTeamMember;
  members: CareTeamMember[];
}

// Message Thread Types
export interface MessageThread {
  id: string;
  subject: string;
  lastMessage: string;
  lastMessageDate: string;
  unread: boolean;
}

export interface Member {
  identity: MemberIdentity;
  profile: Profile;
  programming: Programming;
  programChanges: ProgramChange[];
  results: Results;
  wearables: Wearables;
  files: FileCategory[];
  notes: InternalNote[];
  alerts: Alert[];
  auditLog: AuditEntry[];
  billing: Billing;
  connections: Connection[];
  security: SecurityInfo;
  labOrders: LabOrder[];
  supplementOrders: SupplementOrder[];
  pathway: string;
  careTeam: CareTeam;
  messageThreads: MessageThread[];
}
