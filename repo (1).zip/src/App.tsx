import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MemberSidebar } from './components/MemberSidebar';
import { ProgrammingTab } from './components/tabs/ProgrammingTab';
import { ResultsTab } from './components/tabs/ResultsTab';
import { IntegrationsTab } from './components/tabs/IntegrationsTab';
import { ProfileTab } from './components/tabs/ProfileTab';
import { AuditTab } from './components/tabs/AuditTab';
import { BillingTab } from './components/tabs/BillingTab';
import { mockMember } from './lib/mockData';

function App() {
  return (
    <div className="flex h-screen bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Left Sidebar - Fixed 320px */}
      <MemberSidebar identity={mockMember.identity} />

      {/* Main Content Area - Tabbed */}
      <div className="flex-1 flex flex-col">
        <Tabs defaultValue="programming" className="flex-1 flex flex-col">
          <div className="border-b border-zinc-800 bg-zinc-900/50 px-6 pt-4">
            <TabsList className="bg-zinc-800/50 h-11">
              <TabsTrigger value="programming" className="text-sm">Program</TabsTrigger>
              <TabsTrigger value="results" className="text-sm">Results</TabsTrigger>
              <TabsTrigger value="integrations" className="text-sm">Integrations</TabsTrigger>
              <TabsTrigger value="profile" className="text-sm">Profile</TabsTrigger>
              <TabsTrigger value="billing" className="text-sm">Billing</TabsTrigger>
              <TabsTrigger value="audit" className="text-sm">Audit</TabsTrigger>
            </TabsList>
          </div>

          <div className="flex-1 overflow-auto">
            <TabsContent value="programming" className="m-0 h-full">
              <ProgrammingTab 
                programming={mockMember.programming} 
                programChanges={mockMember.programChanges}
                labOrders={mockMember.labOrders}
                supplementOrders={mockMember.supplementOrders}
                medicalHistory={mockMember.profile.medicalHistory}
                pathway={mockMember.pathway}
              />
            </TabsContent>

            <TabsContent value="results" className="m-0 h-full">
              <ResultsTab results={mockMember.results} />
            </TabsContent>

            <TabsContent value="integrations" className="m-0 h-full">
              <IntegrationsTab wearables={mockMember.wearables} />
            </TabsContent>

            <TabsContent value="profile" className="m-0 h-full">
              <ProfileTab
                profile={mockMember.profile}
                notes={mockMember.notes}
                alerts={mockMember.alerts}
                files={mockMember.files}
                connections={mockMember.connections}
                security={mockMember.security}
                careTeam={mockMember.careTeam}
                messageThreads={mockMember.messageThreads}
              />
            </TabsContent>

            <TabsContent value="billing" className="m-0 h-full">
              <BillingTab billing={mockMember.billing} />
            </TabsContent>

            <TabsContent value="audit" className="m-0 h-full">
              <AuditTab auditLog={mockMember.auditLog} />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}

export default App;
