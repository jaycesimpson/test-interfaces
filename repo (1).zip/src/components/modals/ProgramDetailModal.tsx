import { useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Calendar, Save, X, Plus, AlertCircle, TrendingUp, TrendingDown, Activity, BarChart3, StickyNote, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { LabOrdering } from '../LabOrdering';
import type { ProgramHistory, LabOrder } from '@/lib/types';

interface ProgramDetailModalProps {
  pillar: 'medical' | 'performance' | 'nutrition' | 'recovery';
  pillarData: ProgramHistory;
  labOrders?: LabOrder[];
  onClose: () => void;
}

const pillarTitles = {
  medical: 'Medical Program',
  performance: 'Performance Program',
  nutrition: 'Nutrition Plan',
  recovery: 'Recovery Protocol',
};

const programTemplates = {
  performance: [
    { id: 'marathon-build', name: 'Marathon Build Phase', fields: ['weeklyMileage', 'longRunDistance', 'intensityDays'] },
    { id: 'strength-hypertrophy', name: 'Strength & Hypertrophy', fields: ['sessionsPerWeek', 'primaryLifts', 'volumeLoad'] },
    { id: 'general-fitness', name: 'General Fitness', fields: ['sessionsPerWeek', 'focusAreas'] },
  ],
  nutrition: [
    { id: 'performance-nutrition', name: 'Performance Nutrition', fields: ['calories', 'macroRatio', 'mealTiming'] },
    { id: 'weight-loss', name: 'Weight Loss Protocol', fields: ['calories', 'deficitPercentage', 'mealFrequency'] },
    { id: 'maintenance', name: 'Maintenance Plan', fields: ['calories', 'flexibility'] },
  ],
  recovery: [
    { id: 'active-recovery', name: 'Active Recovery Protocol', fields: ['modalitiesPerWeek', 'sleepTarget'] },
    { id: 'injury-rehab', name: 'Injury Rehabilitation', fields: ['targetArea', 'restrictions', 'progressionCriteria'] },
  ],
  medical: [
    { id: 'chronic-condition', name: 'Chronic Condition Management', fields: ['labFrequency', 'medications', 'checkInSchedule'] },
    { id: 'preventive', name: 'Preventive Care', fields: ['screenings', 'checkInFrequency'] },
  ],
};

const mockActivityData = [
  { date: '2024-01-24', type: 'completed', description: 'Completed long run - 18 miles', feedback: 'Felt strong, no issues' },
  { date: '2024-01-23', type: 'completed', description: 'Easy run - 6 miles', feedback: null },
  { date: '2024-01-22', type: 'completed', description: 'Interval session - 8x800m', feedback: 'Hit all target paces' },
  { date: '2024-01-21', type: 'skipped', description: 'Rest day', feedback: null },
  { date: '2024-01-20', type: 'completed', description: 'Tempo run - 10 miles', feedback: 'Struggled in final 2 miles' },
];

const mockReportData = [
  { metric: 'Weekly Volume', current: '52 miles', vsPrevious: '+8%', trend: 'up' },
  { metric: 'Avg Pace', current: '8:15 /mile', vsPrevious: '-12 sec', trend: 'up' },
  { metric: 'Workout Completion', current: '87%', vsPrevious: '-5%', trend: 'down' },
  { metric: 'Injury Risk Score', current: 'Low', vsPrevious: 'Stable', trend: 'neutral' },
];

const mockNotes = [
  {
    id: 'note-1',
    author: 'Coach Mike Johnson',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    content: 'Reduced weekly mileage this week due to reported fatigue. Will reassess next week.',
    createdAt: '2024-01-22T14:30:00Z',
  },
  {
    id: 'note-2',
    author: 'Coach Mike Johnson',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    content: 'Great progress on speed work. Consider adding hill repeats in next phase.',
    createdAt: '2024-01-15T09:20:00Z',
  },
];

export function ProgramDetailModal({ pillar, pillarData, labOrders = [], onClose }: ProgramDetailModalProps) {
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [queuedProgram, setQueuedProgram] = useState(false);
  const [selectedHistoryItem, setSelectedHistoryItem] = useState<string | null>(null);

  const templates = programTemplates[pillar] || [];
  const selectedTemplateData = templates.find(t => t.id === selectedTemplate);

  return (
    <Sheet open={true} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:max-w-5xl bg-zinc-900 border-zinc-800 p-0 flex flex-col">
        <SheetHeader className="p-6 border-b border-zinc-800 flex-shrink-0">
          <div className="flex items-center justify-between">
            <SheetTitle className="text-zinc-100 text-2xl">
              {pillarTitles[pillar]}
            </SheetTitle>
            {pillarData.current?.alertNote && (
              <Badge className="bg-red-500/10 text-red-400 border-red-500/30">
                <AlertCircle className="w-3 h-3 mr-1" />
                Alert Active
              </Badge>
            )}
          </div>
        </SheetHeader>

        <Tabs defaultValue="assign" className="flex-1 flex flex-col overflow-hidden">
          <div className="px-6 pt-4 flex-shrink-0">
            <TabsList className="w-full justify-start bg-zinc-800/50">
              <TabsTrigger value="assign">Assign</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
            </TabsList>
          </div>

          <ScrollArea className="flex-1 px-6 py-6">
            {/* Assign Tab */}
            <TabsContent value="assign" className="mt-0 space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="template" className="text-zinc-300">Program Template *</Label>
                  <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                    <SelectTrigger className="mt-1.5 bg-zinc-800 border-zinc-700 text-zinc-100">
                      <SelectValue placeholder="Select a program template..." />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800 border-zinc-700">
                      {templates.map((template) => (
                        <SelectItem key={template.id} value={template.id} className="text-zinc-100">
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedTemplateData && (
                  <Card className="bg-zinc-800/30 border-zinc-700">
                    <CardContent className="pt-4 space-y-4">
                      {selectedTemplateData.fields.map((field) => (
                        <div key={field}>
                          <Label className="text-zinc-300 capitalize">
                            {field.replace(/([A-Z])/g, ' $1').trim()}
                          </Label>
                          <Input
                            placeholder={`Enter ${field}...`}
                            className="mt-1.5 bg-zinc-900 border-zinc-700 text-zinc-100"
                          />
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="startDate" className="text-zinc-300">Start Date *</Label>
                    <Input
                      id="startDate"
                      type="date"
                      className="mt-1.5 bg-zinc-800 border-zinc-700 text-zinc-100"
                    />
                  </div>
                  <div>
                    <Label htmlFor="endDate" className="text-zinc-300">End Date *</Label>
                    <Input
                      id="endDate"
                      type="date"
                      className="mt-1.5 bg-zinc-800 border-zinc-700 text-zinc-100"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="assignedBy" className="text-zinc-300">Assigned By</Label>
                  <Input
                    id="assignedBy"
                    defaultValue="You (Current User)"
                    disabled
                    className="mt-1.5 bg-zinc-800/50 border-zinc-700 text-zinc-400"
                  />
                </div>

                <div>
                  <Label htmlFor="instructions" className="text-zinc-300">Instructions for Member</Label>
                  <Textarea
                    id="instructions"
                    placeholder="Add any special instructions, notes, or context for the member..."
                    className="mt-1.5 bg-zinc-800 border-zinc-700 text-zinc-100 min-h-[100px]"
                  />
                </div>

                <div>
                  <Label className="text-zinc-300">File Attachments (PDFs, Videos, Images)</Label>
                  <div className="mt-1.5 border-2 border-dashed border-zinc-700 rounded-lg p-8 text-center hover:border-zinc-600 transition-colors cursor-pointer">
                    <p className="text-sm text-zinc-500">
                      Click to upload or drag and drop
                    </p>
                    <p className="text-xs text-zinc-600 mt-1">
                      PDF, DOC, MP4, JPG up to 50MB
                    </p>
                  </div>
                </div>

                {/* Queue Next Program */}
                <div className="pt-4 border-t border-zinc-700">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-sm font-semibold text-zinc-200">Queue Next Program</h4>
                      <p className="text-xs text-zinc-500 mt-1">
                        Automatically start a new program when current one ends
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setQueuedProgram(!queuedProgram)}
                      className="border-zinc-700 text-zinc-300"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      {queuedProgram ? 'Remove Queue' : 'Add Queue'}
                    </Button>
                  </div>

                  {queuedProgram && (
                    <Card className="bg-zinc-800/30 border-zinc-700">
                      <CardContent className="pt-4 space-y-4">
                        <Select>
                          <SelectTrigger className="bg-zinc-900 border-zinc-700 text-zinc-100">
                            <SelectValue placeholder="Select next program template..." />
                          </SelectTrigger>
                          <SelectContent className="bg-zinc-800 border-zinc-700">
                            {templates.map((template) => (
                              <SelectItem key={template.id} value={template.id} className="text-zinc-100">
                                {template.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-zinc-500">
                          Will start automatically on {pillarData.current?.endDate || 'program end date'}
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Lab Ordering - Medical Programs Only */}
                {pillar === 'medical' && (
                  <>
                    <Separator className="bg-zinc-700" />
                    <div>
                      <h3 className="text-sm font-semibold text-zinc-300 mb-4">Lab Orders</h3>
                      <LabOrdering existingOrders={labOrders} />
                    </div>
                  </>
                )}
              </div>
            </TabsContent>

            {/* History Tab */}
            <TabsContent value="history" className="mt-0">
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">
                  Program History
                </h3>
                {pillarData.history.length > 0 ? (
                  <div className="space-y-3">
                    {pillarData.history.map((program) => (
                      <Card
                        key={program.id}
                        className={cn(
                          "bg-zinc-800/30 border cursor-pointer transition-all hover:bg-zinc-800/50",
                          selectedHistoryItem === program.id ? 'border-blue-500/50 bg-zinc-800/50' : 'border-zinc-700/50'
                        )}
                        onClick={() => setSelectedHistoryItem(selectedHistoryItem === program.id ? null : program.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="text-sm font-medium text-zinc-200 mb-1">
                                {program.name}
                              </h4>
                              <p className="text-xs text-zinc-500">
                                {new Date(program.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} - {new Date(program.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                              </p>
                            </div>
                            <Badge variant="outline" className="border-zinc-600 text-zinc-400 text-xs">
                              {program.adherenceScore || program.foodLoggingAdherence || 0}% Adherence
                            </Badge>
                          </div>
                          <p className="text-xs text-zinc-500 mb-2">
                            Assigned by {program.assignedBy}
                          </p>

                          {selectedHistoryItem === program.id && (
                            <div className="mt-4 pt-4 border-t border-zinc-700 space-y-3">
                              <div className="grid grid-cols-2 gap-3 text-xs">
                                <div>
                                  <span className="text-zinc-500">Duration:</span>
                                  <span className="text-zinc-300 ml-2">
                                    {Math.ceil((new Date(program.endDate).getTime() - new Date(program.startDate).getTime()) / (1000 * 60 * 60 * 24))} days
                                  </span>
                                </div>
                                <div>
                                  <span className="text-zinc-500">Status:</span>
                                  <span className="text-zinc-300 ml-2 capitalize">{program.status}</span>
                                </div>
                                <div>
                                  <span className="text-zinc-500">Last Edited:</span>
                                  <span className="text-zinc-300 ml-2">
                                    {new Date(program.lastEditedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-zinc-500">Edited By:</span>
                                  <span className="text-zinc-300 ml-2">{program.lastEditedBy}</span>
                                </div>
                              </div>
                              <Button size="sm" variant="outline" className="w-full border-zinc-700 text-zinc-300">
                                View Full Details
                              </Button>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-sm text-zinc-500 text-center py-8 bg-zinc-800/20 rounded-lg border border-zinc-800">
                    No previous programs
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Activity Tab */}
            <TabsContent value="activity" className="mt-0">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">
                    Member Activity & Compliance
                  </h3>
                  <Badge variant="outline" className="border-zinc-600 text-zinc-400">
                    Last 7 days
                  </Badge>
                </div>

                <div className="space-y-2">
                  {mockActivityData.map((activity, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-3 p-3 bg-zinc-800/30 border border-zinc-700/50 rounded-lg hover:bg-zinc-800/50 transition-colors"
                    >
                      <div className={cn(
                        'p-2 rounded-full',
                        activity.type === 'completed' ? 'bg-green-500/10' : 'bg-zinc-700/50'
                      )}>
                        {activity.type === 'completed' ? (
                          <CheckCircle className="w-4 h-4 text-green-400" />
                        ) : (
                          <Activity className="w-4 h-4 text-zinc-500" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-zinc-300">{activity.description}</span>
                          <span className="text-xs text-zinc-600">
                            {new Date(activity.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </span>
                        </div>
                        {activity.feedback && (
                          <p className="text-xs text-zinc-500 italic">"{activity.feedback}"</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Reports Tab */}
            <TabsContent value="reports" className="mt-0">
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4">
                    Performance Metrics
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    {mockReportData.map((metric, index) => (
                      <Card key={index} className="bg-zinc-800/30 border-zinc-700">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <span className="text-xs text-zinc-500">{metric.metric}</span>
                            {metric.trend === 'up' && <TrendingUp className="w-4 h-4 text-green-400" />}
                            {metric.trend === 'down' && <TrendingDown className="w-4 h-4 text-red-400" />}
                          </div>
                          <div className="text-2xl font-semibold text-zinc-200 mb-1">
                            {metric.current}
                          </div>
                          <div className="text-xs text-zinc-500">
                            vs previous: <span className={cn(
                              metric.trend === 'up' ? 'text-green-400' : metric.trend === 'down' ? 'text-red-400' : 'text-zinc-400'
                            )}>
                              {metric.vsPrevious}
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4">
                    Insights & Recommendations
                  </h3>
                  <Card className="bg-blue-500/5 border-blue-500/20">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <BarChart3 className="w-5 h-5 text-blue-400 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-300 mb-1">Positive Training Adaptation</h4>
                          <p className="text-xs text-blue-400/70">
                            Weekly volume is increasing appropriately. Continue current progression for optimal adaptation.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Notes Tab */}
            <TabsContent value="notes" className="mt-0">
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">
                  Staff Notes for {pillarTitles[pillar]}
                </h3>

                {pillarData.current?.alertNote && (
                  <Card className="bg-red-500/10 border-red-500/30">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                        <div className="flex-1">
                          <h4 className="text-sm font-medium text-red-300 mb-1">Important Alert</h4>
                          <p className="text-sm text-red-400/90">{pillarData.current.alertNote}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="space-y-3">
                  {mockNotes.map((note) => (
                    <div
                      key={note.id}
                      className="bg-zinc-800/30 border border-zinc-700/50 rounded-lg p-4"
                    >
                      <div className="flex items-start gap-3 mb-2">
                        <Avatar className="w-7 h-7">
                          <AvatarImage src={note.avatar} />
                          <AvatarFallback>{note.author[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-medium text-zinc-300">{note.author}</div>
                          <div className="text-xs text-zinc-500">
                            {new Date(note.createdAt).toLocaleString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-zinc-400 leading-relaxed pl-10">{note.content}</p>
                    </div>
                  ))}
                </div>

                <div className="pt-4">
                  <Textarea
                    placeholder="Add a note for this program... Use @ to mention team members"
                    className="bg-zinc-800 border-zinc-700 text-zinc-100 text-sm min-h-[80px]"
                  />
                  <div className="flex gap-2 mt-2">
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                      <StickyNote className="w-4 h-4 mr-1" />
                      Add Note
                    </Button>
                    <Button size="sm" variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10">
                      <AlertCircle className="w-4 h-4 mr-1" />
                      Set as Alert
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </ScrollArea>

          {/* Footer Actions */}
          <div className="p-6 border-t border-zinc-800 flex items-center justify-between bg-zinc-900 flex-shrink-0">
            <Button variant="outline" onClick={onClose} className="border-zinc-700 text-zinc-300">
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
