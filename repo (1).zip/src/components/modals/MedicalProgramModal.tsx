import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Save, X, Heart, Shield } from 'lucide-react';
import { LabOrdering } from '../LabOrdering';
import { SupplementOrdering } from '../SupplementOrdering';
import type { ProgramHistory, LabOrder, SupplementOrder, MedicalHistory } from '@/lib/types';

interface MedicalProgramModalProps {
  pillarData: ProgramHistory;
  labOrders: LabOrder[];
  supplementOrders: SupplementOrder[];
  medicalHistory: MedicalHistory;
  onClose: () => void;
}

export function MedicalProgramModal({ 
  pillarData, 
  labOrders, 
  supplementOrders, 
  medicalHistory, 
  onClose 
}: MedicalProgramModalProps) {
  return (
    <Sheet open={true} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:max-w-5xl bg-zinc-900 border-zinc-800 p-0 flex flex-col">
        <SheetHeader className="p-6 border-b border-zinc-800 flex-shrink-0">
          <SheetTitle className="text-zinc-100 text-2xl flex items-center gap-2">
            <Heart className="w-6 h-6 text-teal-400" />
            Medical Program
          </SheetTitle>
        </SheetHeader>

        <Tabs defaultValue="labs" className="flex-1 flex flex-col overflow-hidden">
          <div className="px-6 pt-4 flex-shrink-0">
            <TabsList className="w-full justify-start bg-zinc-800/50">
              <TabsTrigger value="labs">Labs</TabsTrigger>
              <TabsTrigger value="supplements">Supplements</TabsTrigger>
              <TabsTrigger value="history">Medical History</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
            </TabsList>
          </div>

          <ScrollArea className="flex-1 px-6 py-6">
            {/* Labs Tab */}
            <TabsContent value="labs" className="mt-0">
              <LabOrdering existingOrders={labOrders} />
            </TabsContent>

            {/* Supplements Tab */}
            <TabsContent value="supplements" className="mt-0">
              <SupplementOrdering existingOrders={supplementOrders} />
            </TabsContent>

            {/* Medical History Tab */}
            <TabsContent value="history" className="mt-0">
              <div className="space-y-6">
                <Card className="bg-zinc-800/30 border-zinc-700">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <Shield className="w-4 h-4 text-teal-400" />
                      <Badge variant="outline" className="text-teal-400 border-teal-500/30 text-xs">
                        PHI Protected Health Information
                      </Badge>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-semibold text-zinc-300 mb-2">Conditions</h4>
                        <div className="flex flex-wrap gap-2">
                          {medicalHistory.conditions.map((condition, i) => (
                            <Badge key={i} variant="outline" className="border-zinc-600 text-zinc-300">
                              {condition}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <Separator className="bg-zinc-700" />

                      <div>
                        <h4 className="text-sm font-semibold text-zinc-300 mb-2">Current Medications</h4>
                        <div className="space-y-2">
                          {medicalHistory.medications.map((med, i) => (
                            <div key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                              <span className="text-zinc-600">•</span>
                              <span>{med}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <Separator className="bg-zinc-700" />

                      <div>
                        <h4 className="text-sm font-semibold text-zinc-300 mb-2">Allergies</h4>
                        <div className="flex flex-wrap gap-2">
                          {medicalHistory.allergies.map((allergy, i) => (
                            <Badge key={i} className="bg-red-500/10 text-red-400 border-red-500/20">
                              {allergy}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <Separator className="bg-zinc-700" />

                      <div>
                        <h4 className="text-sm font-semibold text-zinc-300 mb-2">Surgical History</h4>
                        <div className="space-y-2">
                          {medicalHistory.surgeries.map((surgery, i) => (
                            <div key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                              <span className="text-zinc-600">•</span>
                              <span>{surgery}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <Button variant="outline" size="sm" className="w-full mt-4 border-zinc-700 text-zinc-300">
                      Edit Medical History
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Notes Tab */}
            <TabsContent value="notes" className="mt-0">
              <div className="space-y-4">
                <p className="text-sm text-zinc-500 text-center py-8">
                  Medical program notes
                </p>
              </div>
            </TabsContent>
          </ScrollArea>

          {/* Footer Actions */}
          <div className="p-6 border-t border-zinc-800 flex items-center justify-between bg-zinc-900 flex-shrink-0">
            <Button variant="outline" onClick={onClose} className="border-zinc-700 text-zinc-300">
              <X className="w-4 h-4 mr-2" />
              Close
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
