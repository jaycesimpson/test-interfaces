import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Download, Filter, Plus, Sparkles, Send, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Results } from '@/lib/types';

interface ResultsTabProps {
  results: Results;
}

export function ResultsTab({ results }: ResultsTabProps) {
  const [aiQuery, setAiQuery] = useState('');

  // Transform body comp data for charting
  const bodyCompData = results.bodyComp.map(scan => ({
    date: new Date(scan.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    'Body Fat %': scan.bodyFat,
    'Lean Mass (kg)': scan.leanMass,
    'Bone Density': scan.boneDensity,
  })).reverse();

  // Transform lab data for trending
  const labTrendData = results.labs.reduce((acc, lab) => {
    const date = new Date(lab.date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    const existing = acc.find(d => d.date === date);
    if (existing) {
      existing[lab.biomarker] = lab.value;
    } else {
      acc.push({ date, [lab.biomarker]: lab.value });
    }
    return acc;
  }, [] as any[]).reverse();

  // Mock weight tracking data
  const weightData = [
    { date: 'Dec 1', weight: 152.3 },
    { date: 'Dec 15', weight: 151.8 },
    { date: 'Jan 1', weight: 151.2 },
    { date: 'Jan 15', weight: 150.5 },
    { date: 'Jan 25', weight: 149.8 },
  ];

  // Mock habit adherence
  const habitData = [
    { week: 'Week 1', meditation: 85, stretching: 92, journaling: 71 },
    { week: 'Week 2', meditation: 78, stretching: 88, journaling: 64 },
    { week: 'Week 3', meditation: 92, stretching: 95, journaling: 85 },
    { week: 'Week 4', meditation: 88, stretching: 91, journaling: 78 },
  ];

  return (
    <div className="flex h-full">
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <Tabs defaultValue="visuals" className="h-full flex flex-col">
          <div className="px-6 pt-6 pb-2">
            <div className="flex items-center justify-between mb-4">
              <TabsList className="bg-zinc-800/50">
                <TabsTrigger value="visuals">Visuals</TabsTrigger>
                <TabsTrigger value="tables">Tables</TabsTrigger>
              </TabsList>
              <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300">
                <Plus className="w-4 h-4 mr-2" />
                Add Widget
              </Button>
            </div>
          </div>

          <div className="flex-1 overflow-auto px-6 pb-6">
            <TabsContent value="visuals" className="mt-0 space-y-6">
              {/* Weight Tracking */}
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-zinc-100 text-base">Weight Tracking</CardTitle>
                    <div className="flex items-center gap-2">
                      <TrendingDown className="w-4 h-4 text-green-400" />
                      <span className="text-sm text-green-400 font-semibold">-2.5 lbs</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={weightData}>
                      <defs>
                        <linearGradient id="weightGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                      <XAxis dataKey="date" stroke="#71717a" style={{ fontSize: '11px' }} />
                      <YAxis stroke="#71717a" style={{ fontSize: '11px' }} domain={[145, 155]} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#27272a',
                          border: '1px solid #3f3f46',
                          borderRadius: '8px',
                          fontSize: '12px',
                        }}
                      />
                      <Area type="monotone" dataKey="weight" stroke="#3b82f6" strokeWidth={2} fill="url(#weightGradient)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Body Composition */}
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader>
                  <CardTitle className="text-zinc-100 text-base">Body Composition Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={bodyCompData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                      <XAxis dataKey="date" stroke="#71717a" style={{ fontSize: '11px' }} />
                      <YAxis stroke="#71717a" style={{ fontSize: '11px' }} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#27272a',
                          border: '1px solid #3f3f46',
                          borderRadius: '8px',
                          fontSize: '12px',
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: '12px' }} />
                      <Line type="monotone" dataKey="Body Fat %" stroke="#22c55e" strokeWidth={2} dot={{ fill: '#22c55e', r: 4 }} />
                      <Line type="monotone" dataKey="Lean Mass (kg)" stroke="#3b82f6" strokeWidth={2} dot={{ fill: '#3b82f6', r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Habit Adherence */}
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader>
                  <CardTitle className="text-zinc-100 text-base">Habit Adherence (Last 4 Weeks)</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={habitData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                      <XAxis dataKey="week" stroke="#71717a" style={{ fontSize: '11px' }} />
                      <YAxis stroke="#71717a" style={{ fontSize: '11px' }} domain={[0, 100]} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#27272a',
                          border: '1px solid #3f3f46',
                          borderRadius: '8px',
                          fontSize: '12px',
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: '12px' }} />
                      <Line type="monotone" dataKey="meditation" stroke="#8b5cf6" strokeWidth={2} />
                      <Line type="monotone" dataKey="stretching" stroke="#14b8a6" strokeWidth={2} />
                      <Line type="monotone" dataKey="journaling" stroke="#f59e0b" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tables" className="mt-0 space-y-6">
              {/* Lab Results Table */}
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-zinc-100 text-base">Lab Results Over Time</CardTitle>
                    <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-zinc-700">
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Date</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Biomarker</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Value</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Range</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.labs.map((lab) => (
                          <tr key={lab.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                            <td className="py-3 px-4 text-zinc-300 whitespace-nowrap">
                              {new Date(lab.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                            </td>
                            <td className="py-3 px-4 text-zinc-300">{lab.biomarker}</td>
                            <td className="py-3 px-4 text-zinc-300 font-semibold">
                              {lab.value} {lab.unit}
                            </td>
                            <td className="py-3 px-4 text-zinc-500 text-xs">
                              {lab.normalRange.min} - {lab.normalRange.max}
                            </td>
                            <td className="py-3 px-4">
                              <Badge variant="outline" className={cn(
                                'text-xs',
                                lab.status === 'normal' && 'border-green-500/30 text-green-400',
                                lab.status === 'high' && 'border-red-500/30 text-red-400',
                                lab.status === 'low' && 'border-yellow-500/30 text-yellow-400'
                              )}>
                                {lab.status}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Body Composition Table */}
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader>
                  <CardTitle className="text-zinc-100 text-base">Body Composition Data</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-zinc-700">
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Scan Date</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Body Fat %</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Lean Mass</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Bone Density</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Change</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.bodyComp.map((scan, index) => {
                          const prevScan = results.bodyComp[index + 1];
                          const fatChange = prevScan ? (scan.bodyFat - prevScan.bodyFat).toFixed(1) : null;
                          return (
                            <tr key={scan.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                              <td className="py-3 px-4 text-zinc-300">
                                {new Date(scan.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                              </td>
                              <td className="py-3 px-4 text-zinc-200 font-semibold">{scan.bodyFat}%</td>
                              <td className="py-3 px-4 text-zinc-300">{scan.leanMass} kg</td>
                              <td className="py-3 px-4 text-zinc-300">{scan.boneDensity}</td>
                              <td className="py-3 px-4">
                                {fatChange && (
                                  <div className={cn(
                                    'flex items-center gap-1 text-xs font-semibold',
                                    Number(fatChange) < 0 ? 'text-green-400' : 'text-red-400'
                                  )}>
                                    {Number(fatChange) < 0 ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                                    {fatChange}%
                                  </div>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Physical Assessment Scores */}
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader>
                  <CardTitle className="text-zinc-100 text-base">Physical Assessment Scores</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {results.assessments.map((assessment, index) => {
                      const prevAssessment = results.assessments[index + 1];
                      const scoreChange = prevAssessment ? assessment.score - prevAssessment.score : null;
                      return (
                        <div key={assessment.id} className="p-4 bg-zinc-800/30 border border-zinc-700/50 rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="text-sm font-medium text-zinc-200">{assessment.type}</h4>
                              <p className="text-xs text-zinc-500 mt-1">
                                {new Date(assessment.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-semibold text-zinc-200">{assessment.score}</div>
                              {scoreChange && (
                                <div className={cn(
                                  'text-xs font-semibold mt-1',
                                  scoreChange > 0 ? 'text-green-400' : 'text-red-400'
                                )}>
                                  {scoreChange > 0 ? '+' : ''}{scoreChange} pts
                                </div>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-zinc-400">{assessment.notes}</p>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Mental Health Assessments */}
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader>
                  <CardTitle className="text-zinc-100 text-base">Standardized Mental Health Assessments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-zinc-700">
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Assessment</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Date</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Score</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Interpretation</th>
                          <th className="text-left py-3 px-4 text-zinc-400 font-medium">Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.mentalHealthAssessments.map((assessment) => (
                          <tr key={assessment.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                            <td className="py-3 px-4">
                              <Badge variant="outline" className="border-zinc-600 text-zinc-300 text-xs">
                                {assessment.type}
                              </Badge>
                            </td>
                            <td className="py-3 px-4 text-zinc-400 text-xs whitespace-nowrap">
                              {new Date(assessment.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                            </td>
                            <td className="py-3 px-4 text-zinc-200 font-semibold">{assessment.score}</td>
                            <td className="py-3 px-4 text-zinc-400">{assessment.interpretation}</td>
                            <td className="py-3 px-4 text-zinc-500 text-xs">{assessment.notes}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </div>

      {/* AI Insights Panel */}
      <div className="w-[360px] border-l border-zinc-800 bg-zinc-900/50 flex flex-col">
        <div className="p-4 border-b border-zinc-800">
          <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            AI Results Insights
          </h3>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-4">
          {/* Suggested Questions */}
          <div>
            <div className="text-xs text-zinc-500 mb-3">Suggested questions:</div>
            <div className="space-y-2">
              {[
                'What trends do you see in body composition?',
                'Are lab results improving over time?',
                'Correlation between weight and adherence?',
                'Summary of last 90 days progress',
              ].map((query, i) => (
                <button
                  key={i}
                  onClick={() => setAiQuery(query)}
                  className="w-full text-left text-xs bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700 rounded-lg p-3 text-zinc-400 transition-colors"
                >
                  {query}
                </button>
              ))}
            </div>
          </div>

          {/* Sample Insights */}
          <Card className="bg-purple-500/10 border-purple-500/30">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-sm font-medium text-purple-300 mb-2">Key Insights</h4>
                  <ul className="text-xs text-purple-400/80 space-y-1.5">
                    <li>• Body fat decreased 3.5% over last 6 months</li>
                    <li>• All thyroid markers within optimal range</li>
                    <li>• Vitamin D levels improved significantly</li>
                    <li>• Functional movement score up 20%</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sample Response */}
          <div className="space-y-3">
            <div className="bg-zinc-800/50 rounded-lg p-3 text-sm text-zinc-300">
              Based on the data, Sarah has made excellent progress. Body composition shows consistent improvement with fat loss and lean mass gain. All biomarkers are trending positively.
            </div>
          </div>
        </div>

        {/* Input */}
        <div className="p-4 border-t border-zinc-800">
          <div className="flex gap-2">
            <Input
              placeholder="Ask about member results..."
              value={aiQuery}
              onChange={(e) => setAiQuery(e.target.value)}
              className="bg-zinc-800 border-zinc-700 text-zinc-100 text-sm"
            />
            <Button size="sm" className="bg-purple-600 hover:bg-purple-700 flex-shrink-0">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
