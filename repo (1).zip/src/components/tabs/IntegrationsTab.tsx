import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { RefreshCw, Plus, X, Check, AlertTriangle, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Wearables } from '@/lib/types';

interface IntegrationsTabProps {
  wearables: Wearables;
}

// Wearable logos (using text for now - can be replaced with actual SVG logos)
const deviceLogos: Record<string, React.ReactNode> = {
  whoop: <div className="font-bold text-lg">WHOOP</div>,
  oura: <div className="font-bold text-lg">ŌURA</div>,
  'eight-sleep': <div className="font-bold text-lg">EIGHT SLEEP</div>,
  'apple-watch': <div className="font-bold text-lg">APPLE</div>,
  garmin: <div className="font-bold text-lg">GARMIN</div>,
};

const getDeviceStatus = (device: any) => {
  const lastSync = new Date(device.lastSync);
  const now = new Date();
  const daysSinceSync = Math.floor((now.getTime() - lastSync.getTime()) / (1000 * 60 * 60 * 24));
  
  if (!device.connected) return { status: 'disconnected', label: 'Connection Lost', color: 'red' };
  if (daysSinceSync >= 7) return { status: 'stale', label: 'No Recent Data', color: 'yellow' };
  return { status: 'active', label: 'Active', color: 'green' };
};

export function IntegrationsTab({ wearables }: IntegrationsTabProps) {
  const [dateRange, setDateRange] = useState('30');
  const [selectedMetrics, setSelectedMetrics] = useState(['hrv', 'sleep']);
  const [availableMetrics] = useState([
    { id: 'hrv', name: 'Heart Rate Variability', source: 'Whoop 4.0' },
    { id: 'sleep', name: 'Sleep Duration', source: 'Oura Ring Gen 3' },
    { id: 'strain', name: 'Daily Strain', source: 'Whoop 4.0' },
    { id: 'recovery', name: 'Recovery Score', source: 'Whoop 4.0' },
    { id: 'steps', name: 'Daily Steps', source: 'Multiple Sources' },
    { id: 'heartRate', name: 'Resting Heart Rate', source: 'Multiple Sources' },
  ]);

  const filteredData = wearables.metrics.hrv.slice(-Number(dateRange));

  return (
    <div className="p-6 space-y-6">
      {/* Connected Wearables */}
      <Card className="bg-zinc-800/50 border-zinc-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-zinc-100">Connected Wearables</CardTitle>
            <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300">
              <Plus className="w-4 h-4 mr-2" />
              Request Connection
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            {wearables.devices.map((device) => {
              const deviceStatus = getDeviceStatus(device);
              return (
                <Card
                  key={device.id}
                  className="bg-zinc-800/30 border-zinc-700 hover:border-zinc-600 transition-colors"
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="text-zinc-400 text-xs">
                        {deviceLogos[device.type]}
                      </div>
                      <Badge variant="outline" className={cn(
                        'text-xs',
                        deviceStatus.color === 'green' && 'border-green-500/30 text-green-400',
                        deviceStatus.color === 'yellow' && 'border-yellow-500/30 text-yellow-400',
                        deviceStatus.color === 'red' && 'border-red-500/30 text-red-400'
                      )}>
                        {deviceStatus.label}
                      </Badge>
                    </div>
                    
                    <h4 className="text-sm font-medium text-zinc-200 mb-2">{device.name}</h4>
                    
                    <div className="space-y-1.5 text-xs">
                      <div className="flex items-center justify-between text-zinc-500">
                        <span>Last Sync:</span>
                        <span className="text-zinc-400">
                          {new Date(device.lastSync).toLocaleString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    </div>

                    <Button size="sm" variant="outline" className="w-full mt-3 border-zinc-700 text-zinc-400 h-8">
                      <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
                      Force Sync
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <p className="text-xs text-zinc-500 mt-4">
            New devices connected by the member will automatically appear here. Data is aggregated through Junction API.
          </p>
        </CardContent>
      </Card>

      {/* Metrics Dashboard */}
      <Card className="bg-zinc-800/50 border-zinc-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-zinc-100">Metrics Dashboard</CardTitle>
            <div className="flex items-center gap-2">
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-28 bg-zinc-900 border-zinc-700 h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-800 border-zinc-700">
                  <SelectItem value="7">7 days</SelectItem>
                  <SelectItem value="30">30 days</SelectItem>
                  <SelectItem value="90">90 days</SelectItem>
                </SelectContent>
              </Select>
              <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300">
                <Plus className="w-4 h-4 mr-2" />
                Add Metric
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Active Metrics */}
          {selectedMetrics.includes('hrv') && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="text-sm font-semibold text-zinc-200">Heart Rate Variability</h4>
                  <p className="text-xs text-zinc-500 mt-0.5">
                    Data source: Whoop 4.0 
                    <button className="ml-2 text-purple-400 hover:text-purple-300">
                      (toggle sources)
                    </button>
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedMetrics(selectedMetrics.filter(m => m !== 'hrv'))}
                  className="h-7 w-7 p-0 text-zinc-500 hover:text-zinc-300"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={filteredData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                  <XAxis
                    dataKey="date"
                    stroke="#71717a"
                    style={{ fontSize: '11px' }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis stroke="#71717a" style={{ fontSize: '11px' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#27272a',
                      border: '1px solid #3f3f46',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Line type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {selectedMetrics.includes('sleep') && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="text-sm font-semibold text-zinc-200">Sleep Duration</h4>
                  <p className="text-xs text-zinc-500 mt-0.5">
                    Data source: Oura Ring Gen 3, Eight Sleep Pod
                    <button className="ml-2 text-purple-400 hover:text-purple-300">
                      (toggle sources)
                    </button>
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedMetrics(selectedMetrics.filter(m => m !== 'sleep'))}
                  className="h-7 w-7 p-0 text-zinc-500 hover:text-zinc-300"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={wearables.metrics.sleep.slice(-Number(dateRange))}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                  <XAxis
                    dataKey="date"
                    stroke="#71717a"
                    style={{ fontSize: '11px' }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis stroke="#71717a" style={{ fontSize: '11px' }} domain={[0, 10]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#27272a',
                      border: '1px solid #3f3f46',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Line type="monotone" dataKey="value" stroke="#14b8a6" strokeWidth={2} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Available Metrics Library */}
          {selectedMetrics.length < availableMetrics.length && (
            <div className="pt-4 border-t border-zinc-700">
              <h4 className="text-xs font-semibold text-zinc-500 mb-3 uppercase">Available Metrics</h4>
              <div className="space-y-2">
                {availableMetrics
                  .filter(metric => !selectedMetrics.includes(metric.id))
                  .map((metric) => (
                    <button
                      key={metric.id}
                      onClick={() => setSelectedMetrics([...selectedMetrics, metric.id])}
                      className="w-full flex items-center justify-between p-2 bg-zinc-800/30 hover:bg-zinc-800/50 border border-zinc-700/50 rounded-lg transition-colors"
                    >
                      <div className="text-left">
                        <div className="text-xs font-medium text-zinc-300">{metric.name}</div>
                        <div className="text-xs text-zinc-600">{metric.source}</div>
                      </div>
                      <Plus className="w-4 h-4 text-zinc-500" />
                    </button>
                  ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
