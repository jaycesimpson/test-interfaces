import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  MapPin, Target, StickyNote, AlertTriangle, FileText,
  Users, Mail, MessageSquare, Lock, UserCog, Chrome, Apple as AppleIcon,
  Phone, Key, QrCode, Camera, Tag
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Profile, InternalNote, Alert, FileCategory, Connection, SecurityInfo, CareTeam, MessageThread } from '@/lib/types';

interface ProfileTabProps {
  profile: Profile;
  notes: InternalNote[];
  alerts: Alert[];
  files: FileCategory[];
  connections: Connection[];
  security: SecurityInfo;
  careTeam: CareTeam;
  messageThreads: MessageThread[];
}

export function ProfileTab({ profile, notes, alerts, files, connections, security, careTeam, messageThreads }: ProfileTabProps) {
  return (
    <div className="grid grid-cols-2 gap-6 p-6">
      {/* Left Column - Profile Data */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-zinc-100 mb-4">Profile Information</h2>

        <Accordion type="single" collapsible className="space-y-2">
          <AccordionItem value="demographics" className="bg-zinc-800/50 border border-zinc-700 rounded-lg px-4">
            <AccordionTrigger className="text-zinc-200 hover:text-zinc-100 py-4">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-zinc-400" />
                Demographics
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-zinc-400 space-y-3 pb-4">
              <div>
                <div className="text-xs text-zinc-500">Address</div>
                <div className="text-zinc-300 mt-1">{profile.demographics.address}</div>
              </div>
              <div>
                <div className="text-xs text-zinc-500">Occupation</div>
                <div className="text-zinc-300 mt-1">{profile.demographics.occupation}</div>
              </div>
              <div>
                <div className="text-xs text-zinc-500">Education</div>
                <div className="text-zinc-300 mt-1">{profile.demographics.education}</div>
              </div>
              <div>
                <div className="text-xs text-zinc-500">Family Status</div>
                <div className="text-zinc-300 mt-1">{profile.demographics.familyStatus}</div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="goals" className="bg-zinc-800/50 border border-zinc-700 rounded-lg px-4">
            <AccordionTrigger className="text-zinc-200 hover:text-zinc-100 py-4">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-zinc-400" />
                Goals
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-zinc-400 space-y-2 pb-4">
              {profile.goals.map((goal, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 flex-shrink-0" />
                  <div className="text-zinc-300 text-xs">{goal}</div>
                </div>
              ))}
            </AccordionContent>
          </AccordionItem>

          {/* Care Team */}
          <AccordionItem value="care-team" className="bg-zinc-800/50 border border-zinc-700 rounded-lg px-4">
            <AccordionTrigger className="text-zinc-200 hover:text-zinc-100 py-4">
              <div className="flex items-center gap-2">
                <UserCog className="w-4 h-4 text-zinc-400" />
                Care Team
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-zinc-400 space-y-3 pb-4">
              {/* Care Coordinator */}
              <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={careTeam.coordinator.avatar} />
                    <AvatarFallback>{careTeam.coordinator.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-zinc-200">{careTeam.coordinator.name}</div>
                    <Badge variant="outline" className="mt-1 text-blue-400 border-blue-500/30 text-xs">
                      {careTeam.coordinator.role}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Care Team Members */}
              <div className="space-y-2">
                {careTeam.members.map((member) => (
                  <div key={member.id} className="flex items-center gap-3 p-2 bg-zinc-800/30 rounded-lg">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>{member.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-zinc-300">{member.name}</div>
                      <div className="text-xs text-zinc-600">{member.role}</div>
                    </div>
                  </div>
                ))}
              </div>

              <Button size="sm" variant="outline" className="w-full border-zinc-700 text-zinc-300 mt-2">
                Manage Care Team
              </Button>
            </AccordionContent>
          </AccordionItem>

          {/* Connections */}
          <AccordionItem value="connections" className="bg-zinc-800/50 border border-zinc-700 rounded-lg px-4">
            <AccordionTrigger className="text-zinc-200 hover:text-zinc-100 py-4">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-zinc-400" />
                Connections
                <Badge variant="outline" className="ml-auto mr-2 border-zinc-600 text-zinc-400 text-xs">
                  {connections.length}
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-zinc-400 space-y-3 pb-4">
              {connections.map((connection) => (
                <div key={connection.id} className="flex items-center justify-between p-3 bg-zinc-800/30 rounded-lg border border-zinc-700/50">
                  <div className="flex-1">
                    <div className="text-sm font-medium text-zinc-200">{connection.name}</div>
                    <div className="text-xs text-zinc-500 mt-1">{connection.email}</div>
                    <div className="flex items-center gap-2 mt-1.5">
                      <Badge variant="outline" className="border-zinc-600 text-zinc-400 text-xs">
                        {connection.relationship}
                      </Badge>
                      <Badge variant="outline" className={cn(
                        'text-xs',
                        connection.status === 'active' && 'border-green-500/30 text-green-400',
                        connection.status === 'pending' && 'border-yellow-500/30 text-yellow-400',
                        connection.status === 'inactive' && 'border-zinc-600 text-zinc-500'
                      )}>
                        {connection.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
              <Button size="sm" variant="outline" className="w-full border-zinc-700 text-zinc-300 mt-2">
                + Add Connection
              </Button>
            </AccordionContent>
          </AccordionItem>

          {/* Security & Access */}
          <AccordionItem value="security" className="bg-zinc-800/50 border border-zinc-700 rounded-lg px-4">
            <AccordionTrigger className="text-zinc-200 hover:text-zinc-100 py-4">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-zinc-400" />
                Security & Access
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-zinc-400 space-y-4 pb-4">
              {/* Linked Accounts */}
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 bg-zinc-800/30 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Chrome className="w-5 h-5 text-zinc-400" />
                    <div>
                      <div className="text-sm text-zinc-300">Google Sign-In</div>
                      <div className="text-xs text-zinc-600">
                        {security.googleLinked ? 'Linked' : 'Not linked'}
                      </div>
                    </div>
                  </div>
                  {security.googleLinked && (
                    <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-400 h-7 text-xs">
                      Unlink
                    </Button>
                  )}
                </div>

                <div className="flex items-center justify-between p-3 bg-zinc-800/30 rounded-lg">
                  <div className="flex items-center gap-3">
                    <AppleIcon className="w-5 h-5 text-zinc-400" />
                    <div>
                      <div className="text-sm text-zinc-300">Apple Sign-In</div>
                      <div className="text-xs text-zinc-600">
                        {security.appleLinked ? 'Linked' : 'Not linked'}
                      </div>
                    </div>
                  </div>
                  {security.appleLinked && (
                    <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-400 h-7 text-xs">
                      Unlink
                    </Button>
                  )}
                </div>
              </div>

              <Separator className="bg-zinc-700" />

              {/* Actions */}
              <div className="grid grid-cols-2 gap-2">
                <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300 text-xs h-8">
                  <Lock className="w-3.5 h-3.5 mr-1.5" />
                  Reset Password
                </Button>
                <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300 text-xs h-8">
                  <Key className="w-3.5 h-3.5 mr-1.5" />
                  One-Time Password
                </Button>
                <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300 text-xs h-8">
                  <QrCode className="w-3.5 h-3.5 mr-1.5" />
                  6-Digit Code
                </Button>
                <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300 text-xs h-8">
                  <Mail className="w-3.5 h-3.5 mr-1.5" />
                  Change Email
                </Button>
                <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300 text-xs h-8">
                  <Phone className="w-3.5 h-3.5 mr-1.5" />
                  Change Phone
                </Button>
                <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300 text-xs h-8">
                  <Camera className="w-3.5 h-3.5 mr-1.5" />
                  Change Photo
                </Button>
                <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300 text-xs h-8 col-span-2">
                  <Tag className="w-3.5 h-3.5 mr-1.5" />
                  Manage Tags
                </Button>
              </div>

              <div className="text-xs text-zinc-600 mt-2">
                Last password change: {new Date(security.lastPasswordChange).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>

      {/* Right Column - Internal Tools */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-zinc-100 mb-4">Internal Tools</h2>

        {/* Alerts */}
        {alerts.length > 0 && (
          <Card className="bg-blue-500/10 border-blue-500/20">
            <CardContent className="p-4">
              {alerts.map((alert) => (
                <div key={alert.id} className="flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-blue-400 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm text-blue-300">{alert.message}</p>
                    <p className="text-xs text-blue-500 mt-1">
                      {new Date(alert.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Recent Message Threads */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-base flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Recent Messages
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {messageThreads.map((thread) => (
              <div
                key={thread.id}
                className={cn(
                  'p-3 rounded-lg border cursor-pointer hover:bg-zinc-800/50 transition-colors',
                  thread.unread ? 'bg-blue-500/5 border-blue-500/20' : 'bg-zinc-800/30 border-zinc-700/50'
                )}
              >
                <div className="flex items-start justify-between mb-1">
                  <h4 className="text-sm font-medium text-zinc-300">{thread.subject}</h4>
                  {thread.unread && (
                    <Badge className="bg-blue-500 text-white text-xs h-5">New</Badge>
                  )}
                </div>
                <p className="text-xs text-zinc-500 line-clamp-1">{thread.lastMessage}</p>
                <div className="text-xs text-zinc-600 mt-1">
                  {new Date(thread.lastMessageDate).toLocaleString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </div>
              </div>
            ))}
            <Button size="sm" variant="outline" className="w-full border-zinc-700 text-zinc-300 mt-2">
              View All Messages
            </Button>
          </CardContent>
        </Card>

        {/* Staff Notes */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-base flex items-center gap-2">
              <StickyNote className="w-4 h-4" />
              Internal Notes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {notes.map((note) => (
              <div
                key={note.id}
                className={cn(
                  'bg-zinc-800/30 border rounded-lg p-3',
                  note.pinned ? 'border-yellow-500/30' : 'border-zinc-700/50'
                )}
              >
                <div className="flex items-start gap-3 mb-2">
                  <Avatar className="w-6 h-6">
                    <AvatarImage src={note.authorAvatar} />
                    <AvatarFallback>{note.author[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-zinc-300">{note.author}</div>
                    <div className="text-xs text-zinc-500">
                      {new Date(note.createdAt).toLocaleString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                  </div>
                  {note.pinned && (
                    <Badge variant="outline" className="border-yellow-500/30 text-yellow-400 text-xs">
                      Pinned
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-zinc-400 leading-relaxed">{note.content}</p>
              </div>
            ))}

            <div className="pt-2">
              <Textarea
                placeholder="Add an internal note... Use @ to mention team members"
                className="bg-zinc-800 border-zinc-700 text-zinc-100 text-sm min-h-[80px]"
              />
              <Button size="sm" className="mt-2 bg-blue-600 hover:bg-blue-700 text-white">
                Add Note
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Files */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-base flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Files
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {files.map((category) => (
              <div key={category.category}>
                <h4 className="text-xs font-semibold text-zinc-500 mb-2">{category.category}</h4>
                <div className="space-y-1.5">
                  {category.files.map((file) => (
                    <div
                      key={file.id}
                      className="flex items-center justify-between p-2 bg-zinc-800/30 rounded hover:bg-zinc-800/50 transition-colors cursor-pointer"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-zinc-300 truncate">{file.name}</div>
                        <div className="text-xs text-zinc-600">{file.size}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            <Button size="sm" variant="outline" className="w-full border-zinc-700 text-zinc-300 mt-2">
              + Upload File
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
