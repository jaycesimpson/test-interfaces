import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Battery, Wifi, WifiOff, Send, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Wearables } from '@/lib/types';

interface WearablesTabProps {
  wearables: Wearables;
}

const deviceIcons: Record<string, string> = {
  whoop: '💪',
  oura: '💍',
  'eight-sleep': '🛏️',
  'apple-watch': '⌚',
  garmin: '🏃',
};

export function WearablesTab({ wearables }: WearablesTabProps) {
  return (
    <div className="flex h-full">
      {/* Main Content */}
      <div className="flex-1 p-6 space-y-6">
        {/* Device Cards */}
        <div>
          <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4">
            Connected Devices
          </h3>
          <div className="grid grid-cols-3 gap-4">
            {wearables.devices.map((device) => (
              <Card
                key={device.id}
                className="bg-zinc-800/50 border-zinc-700 hover:border-zinc-600 transition-colors"
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-2xl">{deviceIcons[device.type]}</span>
                    <div className="flex items-center gap-1">
                      {device.connected ? (
                        <Wifi className="w-3.5 h-3.5 text-green-400" />
                      ) : (
                        <WifiOff className="w-3.5 h-3.5 text-red-400" />
                      )}
                      <Battery
                        className={cn(
                          'w-3.5 h-3.5',
                          device.battery > 50 ? 'text-green-400' : device.battery > 20 ? 'text-yellow-400' : 'text-red-400'
                        )}
                      />
                    </div>
                  </div>
                  <h4 className="text-sm font-medium text-zinc-200 mb-1">{device.name}</h4>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-500">
                      {new Date(device.lastSync).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <span className="text-zinc-500">{device.battery}%</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Metrics Charts */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">
              Metrics Dashboard
            </h3>
            <div className="flex gap-2">
              <Badge variant="outline" className="border-zinc-700 text-zinc-300 cursor-pointer hover:bg-zinc-800">
                7d
              </Badge>
              <Badge variant="outline" className="border-zinc-700 text-zinc-300 cursor-pointer hover:bg-zinc-800">
                30d
              </Badge>
              <Badge variant="outline" className="border-zinc-700 text-zinc-300 cursor-pointer hover:bg-zinc-800">
                90d
              </Badge>
            </div>
          </div>

          {/* HRV Chart */}
          <Card className="bg-zinc-800/50 border-zinc-700">
            <CardHeader>
              <CardTitle className="text-zinc-100 text-base">Heart Rate Variability (HRV)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={wearables.metrics.hrv}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                  <XAxis
                    dataKey="date"
                    stroke="#71717a"
                    style={{ fontSize: '11px' }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis stroke="#71717a" style={{ fontSize: '11px' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#27272a',
                      border: '1px solid #3f3f46',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Line type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Sleep Chart */}
          <Card className="bg-zinc-800/50 border-zinc-700">
            <CardHeader>
              <CardTitle className="text-zinc-100 text-base">Sleep Duration (hours)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={wearables.metrics.sleep}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                  <XAxis
                    dataKey="date"
                    stroke="#71717a"
                    style={{ fontSize: '11px' }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis stroke="#71717a" style={{ fontSize: '11px' }} domain={[0, 10]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#27272a',
                      border: '1px solid #3f3f46',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Line type="monotone" dataKey="value" stroke="#14b8a6" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI Chat Sidebar */}
      <div className="w-[320px] border-l border-zinc-800 bg-zinc-900/50 flex flex-col">
        <div className="p-4 border-b border-zinc-800">
          <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            AI Data Assistant
          </h3>
        </div>

        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {/* Example queries */}
            <div className="text-xs text-zinc-500 mb-4">Try asking:</div>
            <div className="space-y-2">
              {[
                'Show me HRV trends when sleep < 7 hours',
                'Correlate training volume with recovery scores',
                'What are my sleep patterns this week?',
              ].map((query, i) => (
                <button
                  key={i}
                  className="w-full text-left text-xs bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700 rounded-lg p-3 text-zinc-400 transition-colors"
                >
                  {query}
                </button>
              ))}
            </div>

            {/* Sample Chat Messages */}
            <div className="mt-6 space-y-3">
              <div className="bg-zinc-800/50 rounded-lg p-3 text-sm text-zinc-300">
                Your average HRV is 58.2 over the past 30 days, with a positive trend of +8% compared to the previous period.
              </div>
            </div>
          </div>
        </ScrollArea>

        <div className="p-4 border-t border-zinc-800">
          <div className="flex gap-2">
            <Input
              placeholder="Ask about member data..."
              className="bg-zinc-800 border-zinc-700 text-zinc-100 text-sm"
            />
            <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
