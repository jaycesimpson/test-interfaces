import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { User, UserCog } from 'lucide-react';
import type { AuditEntry } from '@/lib/types';

interface AuditTabProps {
  auditLog: AuditEntry[];
}

export function AuditTab({ auditLog }: AuditTabProps) {
  const memberActivity = auditLog.filter(entry => entry.category === 'member');
  const adminActivity = auditLog.filter(entry => entry.category === 'admin');

  return (
    <div className="p-6">
      <div className="grid grid-cols-2 gap-6">
        {/* Member Activity */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-base flex items-center gap-2">
              <User className="w-4 h-4 text-blue-400" />
              Member Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-4">
                {memberActivity.map((entry, index) => (
                  <div key={entry.id} className="relative">
                    {index !== memberActivity.length - 1 && (
                      <div className="absolute left-4 top-12 bottom-0 w-px bg-blue-500/20" />
                    )}
                    <div className="flex gap-3">
                      <Avatar className="w-8 h-8 border-2 border-blue-500/20">
                        <AvatarImage src={entry.userAvatar} />
                        <AvatarFallback>{entry.user[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-zinc-300">{entry.user}</span>
                          <span className="text-xs text-zinc-600">
                            {new Date(entry.timestamp).toLocaleString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <p className="text-sm text-zinc-400">{entry.action}</p>
                        {entry.affectedData && (
                          <Badge variant="outline" className="border-zinc-600 text-zinc-500 text-xs mt-2">
                            {entry.affectedData}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Admin Actions */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-base flex items-center gap-2">
              <UserCog className="w-4 h-4 text-orange-400" />
              Admin Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-4">
                {adminActivity.map((entry, index) => (
                  <div key={entry.id} className="relative">
                    {index !== adminActivity.length - 1 && (
                      <div className="absolute left-4 top-12 bottom-0 w-px bg-orange-500/20" />
                    )}
                    <div className="flex gap-3">
                      <Avatar className="w-8 h-8 border-2 border-orange-500/20">
                        <AvatarImage src={entry.userAvatar} />
                        <AvatarFallback>{entry.user[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-zinc-300">{entry.user}</span>
                          <span className="text-xs text-zinc-600">
                            {new Date(entry.timestamp).toLocaleString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <p className="text-sm text-zinc-400">{entry.action}</p>
                        {entry.affectedData && (
                          <Badge variant="outline" className="border-zinc-600 text-zinc-500 text-xs mt-2">
                            {entry.affectedData}
                          </Badge>
                        )}
                        {entry.previousValue && entry.newValue && (
                          <div className="mt-2 text-xs bg-zinc-800/50 rounded p-2 border border-zinc-700/50">
                            <span className="text-red-400 line-through">{entry.previousValue}</span>
                            <span className="text-zinc-500 mx-2">→</span>
                            <span className="text-green-400">{entry.newValue}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
