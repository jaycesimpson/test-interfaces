import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  CreditCard, Calendar, DollarSign, Search, Filter, 
  ShoppingCart, RefreshCw, AlertCircle, Send, StickyNote, Ticket
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Billing } from '@/lib/types';

interface BillingTabProps {
  billing: Billing;
}

export function BillingTab({ billing }: BillingTabProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [transactionFilter, setTransactionFilter] = useState('all');

  const filteredTransactions = billing.transactions.filter(txn => {
    const matchesSearch = txn.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = transactionFilter === 'all' || txn.type === transactionFilter;
    return matchesSearch && matchesFilter;
  });

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6">
        {/* Membership Information */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100">Membership Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-zinc-500 text-xs">Membership Tier</Label>
                <div className="text-zinc-200 font-semibold mt-1">{billing.membership.tier}</div>
              </div>
              <div>
                <Label className="text-zinc-500 text-xs">Billing Cycle</Label>
                <div className="text-zinc-200 font-semibold mt-1 capitalize">{billing.membership.billingCycle}</div>
              </div>
              <div>
                <Label className="text-zinc-500 text-xs">Rate</Label>
                <div className="text-zinc-200 font-semibold mt-1">${billing.membership.rate}/mo</div>
              </div>
            </div>

            <Separator className="bg-zinc-700" />

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-zinc-500 text-xs">Start Date</Label>
                <div className="text-zinc-300 text-sm mt-1">
                  {new Date(billing.membership.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                </div>
              </div>
              {billing.membership.pendingEndDate && (
                <div>
                  <Label className="text-zinc-500 text-xs">Pending End Date</Label>
                  <div className="text-yellow-400 text-sm mt-1">
                    {new Date(billing.membership.pendingEndDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </div>
                </div>
              )}
              {billing.membership.endDate && (
                <div>
                  <Label className="text-zinc-500 text-xs">End Date</Label>
                  <div className="text-red-400 text-sm mt-1">
                    {new Date(billing.membership.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </div>
                </div>
              )}
              {billing.membership.referredBy && (
                <div>
                  <Label className="text-zinc-500 text-xs">Referred By</Label>
                  <div className="text-zinc-300 text-sm mt-1">{billing.membership.referredBy}</div>
                </div>
              )}
            </div>

            {billing.membership.scheduledChange && (
              <>
                <Separator className="bg-zinc-700" />
                <Card className="bg-blue-500/10 border-blue-500/30">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Calendar className="w-5 h-5 text-blue-400 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="text-sm font-medium text-blue-300 mb-1">Scheduled Membership Change</h4>
                        <p className="text-xs text-blue-400/80">
                          Upgrade to <span className="font-semibold">{billing.membership.scheduledChange.newTier}</span> tier
                          at ${billing.membership.scheduledChange.newRate}/mo
                          effective {new Date(billing.membership.scheduledChange.effectiveDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                        </p>
                      </div>
                      <Button size="sm" variant="outline" className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10">
                        Edit
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            <Separator className="bg-zinc-700" />

            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300">
                <Calendar className="w-4 h-4 mr-2" />
                Schedule Change
              </Button>
              <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300">
                Cancel Membership
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Transaction History */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-zinc-100">Transaction History</CardTitle>
              <div className="flex gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <Input
                    placeholder="Search transactions..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 w-64 bg-zinc-900 border-zinc-700 text-zinc-100 h-9"
                  />
                </div>
                <Select value={transactionFilter} onValueChange={setTransactionFilter}>
                  <SelectTrigger className="w-32 bg-zinc-900 border-zinc-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-800 border-zinc-700">
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="subscription">Subscription</SelectItem>
                    <SelectItem value="one-time">One-time</SelectItem>
                    <SelectItem value="refund">Refunds</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-zinc-700">
                    <th className="text-left py-3 px-4 text-zinc-400 font-medium">Date</th>
                    <th className="text-left py-3 px-4 text-zinc-400 font-medium">Description</th>
                    <th className="text-left py-3 px-4 text-zinc-400 font-medium">Amount</th>
                    <th className="text-left py-3 px-4 text-zinc-400 font-medium">Method</th>
                    <th className="text-left py-3 px-4 text-zinc-400 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.map((txn) => (
                    <tr key={txn.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                      <td className="py-3 px-4 text-zinc-300 whitespace-nowrap">
                        {new Date(txn.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </td>
                      <td className="py-3 px-4 text-zinc-300">{txn.description}</td>
                      <td className={cn(
                        "py-3 px-4 font-semibold",
                        txn.amount < 0 ? 'text-red-400' : 'text-zinc-200'
                      )}>
                        ${Math.abs(txn.amount)}
                      </td>
                      <td className="py-3 px-4 text-zinc-500 text-xs">{txn.method}</td>
                      <td className="py-3 px-4">
                        <Badge variant="outline" className={cn(
                          'text-xs',
                          txn.status === 'completed' && 'border-green-500/30 text-green-400',
                          txn.status === 'pending' && 'border-yellow-500/30 text-yellow-400',
                          txn.status === 'failed' && 'border-red-500/30 text-red-400',
                          txn.status === 'refunded' && 'border-purple-500/30 text-purple-400'
                        )}>
                          {txn.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* One-Time Purchases & Refunds */}
        <div className="grid grid-cols-2 gap-6">
          <Card className="bg-zinc-800/50 border-zinc-700">
            <CardHeader>
              <CardTitle className="text-zinc-100 text-base">Initiate Purchase</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-zinc-300">Item/Service</Label>
                <Select>
                  <SelectTrigger className="mt-1.5 bg-zinc-900 border-zinc-700">
                    <SelectValue placeholder="Select item..." />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-800 border-zinc-700">
                    <SelectItem value="dexa">DEXA Scan - $150</SelectItem>
                    <SelectItem value="nutrition-consult">Nutrition Consultation - $125</SelectItem>
                    <SelectItem value="pt-session">PT Session - $100</SelectItem>
                    <SelectItem value="custom">Custom Amount</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-zinc-300">Amount</Label>
                <div className="relative mt-1.5">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <Input type="number" placeholder="0.00" className="pl-9 bg-zinc-900 border-zinc-700 text-zinc-100" />
                </div>
              </div>
              <div>
                <Label className="text-zinc-300">Notes</Label>
                <Textarea placeholder="Optional notes..." className="mt-1.5 bg-zinc-900 border-zinc-700 text-zinc-100" rows={3} />
              </div>
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                <ShoppingCart className="w-4 h-4 mr-2" />
                Process Purchase
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-zinc-800/50 border-zinc-700">
            <CardHeader>
              <CardTitle className="text-zinc-100 text-base">Submit Refund</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-zinc-300">Original Transaction</Label>
                <Select>
                  <SelectTrigger className="mt-1.5 bg-zinc-900 border-zinc-700">
                    <SelectValue placeholder="Select transaction..." />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-800 border-zinc-700">
                    {billing.transactions
                      .filter(t => t.type !== 'refund' && t.status === 'completed')
                      .map(t => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.description} - ${t.amount}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-zinc-300">Refund Amount</Label>
                <div className="relative mt-1.5">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <Input type="number" placeholder="0.00" className="pl-9 bg-zinc-900 border-zinc-700 text-zinc-100" />
                </div>
              </div>
              <div>
                <Label className="text-zinc-300">Reason</Label>
                <Textarea placeholder="Reason for refund..." className="mt-1.5 bg-zinc-900 border-zinc-700 text-zinc-100" rows={3} />
              </div>
              <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                <RefreshCw className="w-4 h-4 mr-2" />
                Process Refund
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Promo Codes & Discounts */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-zinc-100">Promo Codes & Discounts</CardTitle>
              <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300">
                <Ticket className="w-4 h-4 mr-2" />
                Apply New Code
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {billing.promoCodes.map((promo) => (
                <div key={promo.id} className="flex items-center justify-between p-3 bg-zinc-800/30 border border-zinc-700/50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <code className="text-sm font-semibold text-zinc-200 bg-zinc-900 px-2 py-0.5 rounded">
                        {promo.code}
                      </code>
                      <Badge variant="outline" className={cn(
                        'text-xs',
                        promo.status === 'active' && 'border-green-500/30 text-green-400',
                        promo.status === 'expired' && 'border-zinc-600 text-zinc-500',
                        promo.status === 'used' && 'border-purple-500/30 text-purple-400'
                      )}>
                        {promo.status}
                      </Badge>
                    </div>
                    <div className="text-xs text-zinc-500">{promo.discount}</div>
                    <div className="text-xs text-zinc-600 mt-1">
                      Applied {new Date(promo.appliedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      {promo.expiresDate && ` • Expires ${new Date(promo.expiresDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`}
                    </div>
                  </div>
                  {promo.status === 'active' && (
                    <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-400">
                      Remove
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Payment Method */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100">Payment Method</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-zinc-800/30 border border-zinc-700/50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-700">
                  <CreditCard className="w-5 h-5 text-zinc-400" />
                </div>
                <div>
                  <div className="text-sm font-medium text-zinc-200">
                    {billing.paymentMethod.brand} •••• {billing.paymentMethod.last4}
                  </div>
                  {billing.paymentMethod.expiryDate && (
                    <div className="text-xs text-zinc-500 mt-1">
                      Expires {billing.paymentMethod.expiryDate}
                    </div>
                  )}
                </div>
              </div>
              <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-300">
                <Send className="w-4 h-4 mr-2" />
                Request Update
              </Button>
            </div>
            <p className="text-xs text-zinc-500">
              Clicking "Request Update" will send an email to the member with a secure link to update their payment information.
            </p>
          </CardContent>
        </Card>

        {/* Billing Notes & Alerts */}
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100">Billing Notes & Alerts</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {billing.billingNotes.map((note) => (
              <div
                key={note.id}
                className={cn(
                  'p-4 rounded-lg border',
                  note.isAlert 
                    ? 'bg-red-500/10 border-red-500/30' 
                    : 'bg-zinc-800/30 border-zinc-700/50'
                )}
              >
                {note.isAlert && (
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-4 h-4 text-red-400" />
                    <span className="text-xs font-semibold text-red-400 uppercase">Alert</span>
                  </div>
                )}
                <p className="text-sm text-zinc-300 mb-2">{note.content}</p>
                <div className="flex items-center justify-between text-xs text-zinc-500">
                  <span>{note.author}</span>
                  <span>{new Date(note.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>
            ))}

            <div className="pt-4 space-y-3">
              <Textarea
                placeholder="Add a billing note..."
                className="bg-zinc-900 border-zinc-700 text-zinc-100 min-h-[80px]"
              />
              <div className="flex gap-2">
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                  <StickyNote className="w-4 h-4 mr-2" />
                  Add Note
                </Button>
                <Button size="sm" variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  Add as Alert
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  );
}
