import { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RedactedFieldProps {
  label: string;
  value: string;
  className?: string;
}

export function RedactedField({ label, value, className }: RedactedFieldProps) {
  const [isRevealed, setIsRevealed] = useState(false);

  // Generate asterisks based on value length
  const redacted = '****'.repeat(Math.max(1, Math.ceil(value.length / 8)));

  return (
    <div
      className={cn('group relative cursor-pointer', className)}
      onMouseEnter={() => setIsRevealed(true)}
      onMouseLeave={() => setIsRevealed(false)}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="text-xs text-zinc-500 mb-1">{label}</div>
          <div className="text-sm text-zinc-300 transition-all duration-200 font-mono">
            {isRevealed ? value : redacted}
          </div>
        </div>
        <div className="flex-shrink-0">
          {isRevealed ? (
            <Eye className="w-3.5 h-3.5 text-zinc-500" />
          ) : (
            <EyeOff className="w-3.5 h-3.5 text-zinc-600" />
          )}
        </div>
      </div>
    </div>
  );
}
