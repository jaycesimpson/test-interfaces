import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { 
  FlaskConical, Plus, Calendar, DollarSign, MapPin, User, 
  Package, Truck, CheckCircle, Clock, AlertCircle, X
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { LabOrder } from '@/lib/types';

interface LabOrderingProps {
  existingOrders: LabOrder[];
}

// Junction API Lab Bundles (reference: https://docs.junction.com)
const labBundles = [
  {
    id: 'comprehensive-metabolic',
    name: 'Comprehensive Metabolic Panel',
    biomarkers: ['Glucose', 'BUN', 'Creatinine', 'Sodium', 'Potassium', 'Chloride', 'CO2', 'Calcium'],
    price: 89,
  },
  {
    id: 'thyroid-complete',
    name: 'Complete Thyroid Panel',
    biomarkers: ['TSH', 'Free T3', 'Free T4', 'Reverse T3', 'TPO Antibodies', 'TG Antibodies'],
    price: 149,
  },
  {
    id: 'hormone-panel',
    name: 'Hormone Panel',
    biomarkers: ['Testosterone Total', 'Testosterone Free', 'Estradiol', 'DHEA-S', 'Cortisol', 'Progesterone'],
    price: 199,
  },
  {
    id: 'performance-athlete',
    name: 'Performance Athlete Panel',
    biomarkers: ['Iron', 'Ferritin', 'B12', 'Folate', 'Vitamin D', 'Magnesium', 'Zinc'],
    price: 175,
  },
];

const individualBiomarkers = [
  { id: 'tsh', name: 'TSH', price: 25 },
  { id: 'vitamin-d', name: 'Vitamin D', price: 30 },
  { id: 'iron', name: 'Iron', price: 20 },
  { id: 'ferritin', name: 'Ferritin', price: 25 },
  { id: 'b12', name: 'Vitamin B12', price: 25 },
  { id: 'testosterone', name: 'Testosterone Total', price: 35 },
  { id: 'cortisol', name: 'Cortisol', price: 30 },
  { id: 'crp', name: 'C-Reactive Protein', price: 28 },
];

const getOrderStatusInfo = (status: string) => {
  const statusMap = {
    'ordered': { icon: Clock, color: 'zinc', label: 'Ordered' },
    'kit-shipped': { icon: Truck, color: 'blue', label: 'Kit Shipped' },
    'sample-received': { icon: Package, color: 'purple', label: 'Sample Received' },
    'processing': { icon: FlaskConical, color: 'yellow', label: 'Processing' },
    'results-ready': { icon: CheckCircle, color: 'green', label: 'Results Ready' },
    'completed': { icon: CheckCircle, color: 'zinc', label: 'Completed' },
  };
  return statusMap[status as keyof typeof statusMap] || statusMap.ordered;
};

export function LabOrdering({ existingOrders }: LabOrderingProps) {
  const [orderType, setOrderType] = useState<'bundle' | 'custom'>('bundle');
  const [selectedBundle, setSelectedBundle] = useState('');
  const [selectedBiomarkers, setSelectedBiomarkers] = useState<string[]>([]);
  const [showNewOrder, setShowNewOrder] = useState(false);

  const selectedBundleData = labBundles.find(b => b.id === selectedBundle);
  const customTotal = selectedBiomarkers.reduce((sum, id) => {
    const biomarker = individualBiomarkers.find(b => b.id === id);
    return sum + (biomarker?.price || 0);
  }, 0);

  return (
    <div className="space-y-6">
      {/* Existing Lab Orders */}
      {existingOrders.length > 0 && (
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-base">Active & Recent Lab Orders</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {existingOrders.map((order) => {
              const statusInfo = getOrderStatusInfo(order.status);
              const StatusIcon = statusInfo.icon;
              
              return (
                <div key={order.id} className="bg-zinc-800/30 border border-zinc-700/50 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="text-sm font-medium text-zinc-200">
                          {order.type === 'bundle' ? order.bundleName : 'Custom Panel'}
                        </h4>
                        <Badge variant="outline" className={cn(
                          'text-xs',
                          `border-${statusInfo.color}-500/30 text-${statusInfo.color}-400`
                        )}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {statusInfo.label}
                        </Badge>
                      </div>
                      <div className="text-xs text-zinc-500 space-y-1">
                        <div>Order ID: {order.id}</div>
                        <div>Ordered: {new Date(order.orderDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>
                        <div>Due: {new Date(order.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>
                        <div>Ordered by: {order.orderedBy}</div>
                        <div className="capitalize">Draw method: {order.drawMethod.replace('-', ' ')}</div>
                      </div>
                    </div>
                  </div>

                  {/* Biomarkers */}
                  <div className="mb-3">
                    <div className="text-xs text-zinc-500 mb-2">Biomarkers ({order.biomarkers.length}):</div>
                    <div className="flex flex-wrap gap-1.5">
                      {order.biomarkers.map((biomarker, i) => (
                        <Badge key={i} variant="outline" className="border-zinc-600 text-zinc-400 text-xs">
                          {biomarker}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Tracking Info */}
                  {order.trackingInfo && (
                    <div className="pt-3 border-t border-zinc-700/50">
                      <div className="grid grid-cols-3 gap-3 text-xs">
                        {order.trackingInfo.kitShipped && (
                          <div>
                            <div className="text-zinc-500">Kit Shipped</div>
                            <div className="text-zinc-400 mt-1">
                              {new Date(order.trackingInfo.kitShipped).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </div>
                          </div>
                        )}
                        {order.trackingInfo.sampleReceived && (
                          <div>
                            <div className="text-zinc-500">Sample Received</div>
                            <div className="text-zinc-400 mt-1">
                              {new Date(order.trackingInfo.sampleReceived).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </div>
                          </div>
                        )}
                        {order.trackingInfo.resultsReady && (
                          <div>
                            <div className="text-zinc-500">Results Ready</div>
                            <div className="text-zinc-400 mt-1">
                              {new Date(order.trackingInfo.resultsReady).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {order.status === 'results-ready' && (
                    <Button size="sm" className="w-full mt-3 bg-green-600 hover:bg-green-700 text-white">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      View Results
                    </Button>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* New Lab Order */}
      {!showNewOrder ? (
        <Button 
          onClick={() => setShowNewOrder(true)}
          variant="outline" 
          className="w-full border-zinc-700 text-zinc-300 h-12 border-dashed"
        >
          <Plus className="w-4 h-4 mr-2" />
          Place New Lab Order
        </Button>
      ) : (
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-zinc-100 text-base">New Lab Order</CardTitle>
              <Button size="sm" variant="ghost" onClick={() => setShowNewOrder(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Order Type Selection */}
            <div>
              <Label className="text-zinc-300">Order Type</Label>
              <div className="flex gap-2 mt-2">
                <Button
                  size="sm"
                  variant={orderType === 'bundle' ? 'default' : 'outline'}
                  onClick={() => setOrderType('bundle')}
                  className={orderType === 'bundle' ? 'bg-zinc-700' : 'border-zinc-700'}
                >
                  Pre-Built Bundle
                </Button>
                <Button
                  size="sm"
                  variant={orderType === 'custom' ? 'default' : 'outline'}
                  onClick={() => setOrderType('custom')}
                  className={orderType === 'custom' ? 'bg-zinc-700' : 'border-zinc-700'}
                >
                  Custom Panel
                </Button>
              </div>
            </div>

            {orderType === 'bundle' ? (
              <div>
                <Label className="text-zinc-300">Select Lab Bundle</Label>
                <Select value={selectedBundle} onValueChange={setSelectedBundle}>
                  <SelectTrigger className="mt-1.5 bg-zinc-900 border-zinc-700">
                    <SelectValue placeholder="Choose a bundle..." />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-800 border-zinc-700">
                    {labBundles.map((bundle) => (
                      <SelectItem key={bundle.id} value={bundle.id}>
                        {bundle.name} - ${bundle.price}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {selectedBundleData && (
                  <Card className="mt-3 bg-zinc-900/50 border-zinc-700">
                    <CardContent className="p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-zinc-400">Biomarkers Included:</span>
                        <Badge variant="outline" className="border-zinc-600 text-zinc-400 text-xs">
                          ${selectedBundleData.price}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedBundleData.biomarkers.map((biomarker, i) => (
                          <Badge key={i} variant="outline" className="border-zinc-600 text-zinc-300 text-xs">
                            {biomarker}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : (
              <div>
                <Label className="text-zinc-300">Select Individual Biomarkers</Label>
                <div className="mt-2 max-h-64 overflow-auto space-y-2 p-3 bg-zinc-900/50 border border-zinc-700 rounded-lg">
                  {individualBiomarkers.map((biomarker) => (
                    <div key={biomarker.id} className="flex items-center justify-between p-2 hover:bg-zinc-800/50 rounded transition-colors">
                      <div className="flex items-center gap-3">
                        <Checkbox
                          id={biomarker.id}
                          checked={selectedBiomarkers.includes(biomarker.id)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedBiomarkers([...selectedBiomarkers, biomarker.id]);
                            } else {
                              setSelectedBiomarkers(selectedBiomarkers.filter(id => id !== biomarker.id));
                            }
                          }}
                        />
                        <Label htmlFor={biomarker.id} className="text-sm text-zinc-300 cursor-pointer">
                          {biomarker.name}
                        </Label>
                      </div>
                      <span className="text-xs text-zinc-500">${biomarker.price}</span>
                    </div>
                  ))}
                </div>
                {selectedBiomarkers.length > 0 && (
                  <div className="mt-2 flex items-center justify-between text-sm">
                    <span className="text-zinc-400">{selectedBiomarkers.length} biomarkers selected</span>
                    <span className="font-semibold text-zinc-200">Total: ${customTotal}</span>
                  </div>
                )}
              </div>
            )}

            <Separator className="bg-zinc-700" />

            {/* Blood Draw Method */}
            <div>
              <Label className="text-zinc-300">Blood Draw Method</Label>
              <Select>
                <SelectTrigger className="mt-1.5 bg-zinc-900 border-zinc-700">
                  <SelectValue placeholder="Select draw method..." />
                </SelectTrigger>
                <SelectContent className="bg-zinc-800 border-zinc-700">
                  <SelectItem value="veyda">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      <span>Veyda Phlebotomist (at-home)</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="facility">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>Provider Facility</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Due Date */}
            <div>
              <Label className="text-zinc-300">Due Date</Label>
              <Input type="date" className="mt-1.5 bg-zinc-900 border-zinc-700 text-zinc-100" />
            </div>

            {/* Instructions */}
            <div>
              <Label className="text-zinc-300">Instructions / Notes</Label>
              <Textarea
                placeholder="Add any special instructions for the lab order..."
                className="mt-1.5 bg-zinc-900 border-zinc-700 text-zinc-100"
                rows={3}
              />
            </div>

            {/* Custom Fee */}
            <div>
              <Label className="text-zinc-300">Custom Fee (optional)</Label>
              <div className="relative mt-1.5">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <Input
                  type="number"
                  placeholder="0.00"
                  className="pl-9 bg-zinc-900 border-zinc-700 text-zinc-100"
                />
              </div>
              <p className="text-xs text-zinc-500 mt-1">Override default pricing if needed</p>
            </div>

            <Separator className="bg-zinc-700" />

            {/* Submit Order */}
            <div className="flex gap-2">
              <Button
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                disabled={orderType === 'bundle' ? !selectedBundle : selectedBiomarkers.length === 0}
              >
                <FlaskConical className="w-4 h-4 mr-2" />
                Place Lab Order
              </Button>
              <Button variant="outline" onClick={() => setShowNewOrder(false)} className="border-zinc-700 text-zinc-300">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
