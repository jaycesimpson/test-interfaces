export const Roboto = {
  className: "font-roboto",
};
