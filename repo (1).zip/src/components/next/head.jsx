import React from "react";

const Head = ({ children }) => {
  return <div>{children}</div>;
};

export default Head;
