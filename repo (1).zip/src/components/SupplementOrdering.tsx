import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Pill, Plus, X, Calendar, Percent, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { SupplementOrder } from '@/lib/types';

interface SupplementOrderingProps {
  existingOrders: SupplementOrder[];
}

// Fullscript Supplement Bundles
const supplementBundles = [
  {
    id: 'athlete-performance',
    name: 'Athlete Performance Bundle',
    supplements: [
      { name: 'Omega-3 Fish Oil', dosage: '2 capsules daily' },
      { name: 'Magnesium Glycinate', dosage: '400mg before bed' },
      { name: 'Vitamin D3', dosage: '5000 IU daily' },
      { name: 'Creatine Monohydrate', dosage: '5g daily' },
    ],
  },
  {
    id: 'recovery-support',
    name: 'Recovery Support Bundle',
    supplements: [
      { name: 'Curcumin', dosage: '500mg twice daily' },
      { name: 'Tart Cherry Extract', dosage: '1000mg daily' },
      { name: 'Collagen Peptides', dosage: '10g daily' },
    ],
  },
  {
    id: 'immune-boost',
    name: 'Immune Support Bundle',
    supplements: [
      { name: 'Vitamin C', dosage: '1000mg twice daily' },
      { name: 'Zinc', dosage: '30mg daily' },
      { name: 'Vitamin D3', dosage: '5000 IU daily' },
      { name: 'Probiotics', dosage: '1 capsule daily' },
    ],
  },
];

const individualSupplements = [
  { id: 'omega-3', name: 'Omega-3 Fish Oil' },
  { id: 'vitamin-d', name: 'Vitamin D3' },
  { id: 'magnesium', name: 'Magnesium Glycinate' },
  { id: 'b-complex', name: 'B-Complex' },
  { id: 'iron', name: 'Iron (Ferrous Bisglycinate)' },
  { id: 'creatine', name: 'Creatine Monohydrate' },
  { id: 'protein', name: 'Whey Protein' },
  { id: 'probiotics', name: 'Probiotics' },
];

export function SupplementOrdering({ existingOrders }: SupplementOrderingProps) {
  const [orderType, setOrderType] = useState<'bundle' | 'custom'>('bundle');
  const [selectedBundle, setSelectedBundle] = useState('');
  const [selectedSupplements, setSelectedSupplements] = useState<string[]>([]);
  const [showNewOrder, setShowNewOrder] = useState(false);

  const selectedBundleData = supplementBundles.find(b => b.id === selectedBundle);

  return (
    <div className="space-y-6">
      {/* Existing Supplement Orders */}
      {existingOrders.length > 0 && (
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-base">Active Supplement Plans</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {existingOrders.map((order) => (
              <div key={order.id} className="bg-zinc-800/30 border border-zinc-700/50 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="text-sm font-medium text-zinc-200">
                        {order.type === 'bundle' ? order.bundleName : 'Custom Plan'}
                      </h4>
                      <Badge variant="outline" className={cn(
                        'text-xs',
                        order.status === 'active' && 'border-green-500/30 text-green-400',
                        order.status === 'completed' && 'border-zinc-600 text-zinc-500',
                        order.status === 'cancelled' && 'border-red-500/30 text-red-400'
                      )}>
                        {order.status}
                      </Badge>
                    </div>
                    <div className="text-xs text-zinc-500 space-y-1">
                      <div>Order ID: {order.id}</div>
                      <div>Duration: {new Date(order.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {new Date(order.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>
                      <div>Ordered by: {order.orderedBy}</div>
                      {order.discountPercent > 0 && (
                        <div className="text-green-400">Discount: {order.discountPercent}% off</div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Supplements List */}
                <div className="space-y-2">
                  {order.supplements.map((supp) => (
                    <div key={supp.id} className="p-2 bg-zinc-900/50 rounded border border-zinc-700/30">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="text-sm text-zinc-300 font-medium">{supp.name}</div>
                          <div className="text-xs text-zinc-500 mt-1">{supp.dosage}</div>
                          {supp.instructions && (
                            <div className="text-xs text-zinc-600 mt-1 italic">{supp.instructions}</div>
                          )}
                        </div>
                        <Pill className="w-4 h-4 text-zinc-500 flex-shrink-0" />
                      </div>
                    </div>
                  ))}
                </div>

                {order.planNotes && (
                  <div className="mt-3 pt-3 border-t border-zinc-700/50">
                    <p className="text-xs text-zinc-400">{order.planNotes}</p>
                  </div>
                )}

                {order.status === 'active' && (
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" variant="outline" className="flex-1 border-zinc-700 text-zinc-300">
                      View in Fullscript
                    </Button>
                    <Button size="sm" variant="outline" className="border-zinc-700 text-zinc-400">
                      Edit Plan
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* New Supplement Order */}
      {!showNewOrder ? (
        <Button 
          onClick={() => setShowNewOrder(true)}
          variant="outline" 
          className="w-full border-zinc-700 text-zinc-300 h-12 border-dashed"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create New Supplement Plan
        </Button>
      ) : (
        <Card className="bg-zinc-800/50 border-zinc-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-zinc-100 text-base">New Supplement Plan</CardTitle>
              <Button size="sm" variant="ghost" onClick={() => setShowNewOrder(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Order Type */}
            <div>
              <Label className="text-zinc-300">Plan Type</Label>
              <div className="flex gap-2 mt-2">
                <Button
                  size="sm"
                  variant={orderType === 'bundle' ? 'default' : 'outline'}
                  onClick={() => setOrderType('bundle')}
                  className={orderType === 'bundle' ? 'bg-zinc-700' : 'border-zinc-700'}
                >
                  Pre-Built Bundle
                </Button>
                <Button
                  size="sm"
                  variant={orderType === 'custom' ? 'default' : 'outline'}
                  onClick={() => setOrderType('custom')}
                  className={orderType === 'custom' ? 'bg-zinc-700' : 'border-zinc-700'}
                >
                  Custom Plan
                </Button>
              </div>
            </div>

            {orderType === 'bundle' ? (
              <div>
                <Label className="text-zinc-300">Select Bundle</Label>
                <Select value={selectedBundle} onValueChange={setSelectedBundle}>
                  <SelectTrigger className="mt-1.5 bg-zinc-900 border-zinc-700">
                    <SelectValue placeholder="Choose a bundle..." />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-800 border-zinc-700">
                    {supplementBundles.map((bundle) => (
                      <SelectItem key={bundle.id} value={bundle.id}>
                        {bundle.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {selectedBundleData && (
                  <Card className="mt-3 bg-zinc-900/50 border-zinc-700">
                    <CardContent className="p-3 space-y-2">
                      <div className="text-xs text-zinc-400 mb-2">Includes:</div>
                      {selectedBundleData.supplements.map((supp, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs">
                          <CheckCircle className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                          <div>
                            <div className="text-zinc-300">{supp.name}</div>
                            <div className="text-zinc-600">{supp.dosage}</div>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : (
              <div>
                <Label className="text-zinc-300">Select Individual Supplements</Label>
                <div className="mt-2 max-h-64 overflow-auto space-y-2 p-3 bg-zinc-900/50 border border-zinc-700 rounded-lg">
                  {individualSupplements.map((supp) => (
                    <div key={supp.id} className="flex items-center gap-3 p-2 hover:bg-zinc-800/50 rounded transition-colors">
                      <Checkbox
                        id={supp.id}
                        checked={selectedSupplements.includes(supp.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedSupplements([...selectedSupplements, supp.id]);
                          } else {
                            setSelectedSupplements(selectedSupplements.filter(id => id !== supp.id));
                          }
                        }}
                      />
                      <Label htmlFor={supp.id} className="text-sm text-zinc-300 cursor-pointer flex-1">
                        {supp.name}
                      </Label>
                    </div>
                  ))}
                </div>
                {selectedSupplements.length > 0 && (
                  <div className="mt-2 text-sm text-zinc-400">
                    {selectedSupplements.length} supplements selected
                  </div>
                )}
              </div>
            )}

            <Separator className="bg-zinc-700" />

            {/* Date Range */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-zinc-300">Start Date</Label>
                <Input type="date" className="mt-1.5 bg-zinc-900 border-zinc-700 text-zinc-100" />
              </div>
              <div>
                <Label className="text-zinc-300">End Date</Label>
                <Input type="date" className="mt-1.5 bg-zinc-900 border-zinc-700 text-zinc-100" />
              </div>
            </div>

            {/* Discount */}
            <div>
              <Label className="text-zinc-300">Member Discount</Label>
              <div className="relative mt-1.5">
                <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <Input
                  type="number"
                  placeholder="0"
                  min="0"
                  max="100"
                  className="pl-9 bg-zinc-900 border-zinc-700 text-zinc-100"
                />
              </div>
              <p className="text-xs text-zinc-500 mt-1">Percentage discount applied to entire plan</p>
            </div>

            {/* Plan Notes */}
            <div>
              <Label className="text-zinc-300">Plan Notes / Instructions</Label>
              <Textarea
                placeholder="Overall notes for the supplement plan..."
                className="mt-1.5 bg-zinc-900 border-zinc-700 text-zinc-100"
                rows={3}
              />
            </div>

            {/* Per-Supplement Instructions (if custom) */}
            {orderType === 'custom' && selectedSupplements.length > 0 && (
              <div>
                <Label className="text-zinc-300">Individual Instructions</Label>
                <div className="mt-2 space-y-3 p-3 bg-zinc-900/50 border border-zinc-700 rounded-lg max-h-64 overflow-auto">
                  {selectedSupplements.map((suppId) => {
                    const supp = individualSupplements.find(s => s.id === suppId);
                    return (
                      <div key={suppId} className="space-y-2">
                        <div className="text-sm font-medium text-zinc-300">{supp?.name}</div>
                        <Input
                          placeholder="Dosage (e.g., 2 capsules daily)"
                          className="bg-zinc-800 border-zinc-700 text-zinc-100 text-xs h-8"
                        />
                        <Input
                          placeholder="Instructions (e.g., Take with food)"
                          className="bg-zinc-800 border-zinc-700 text-zinc-100 text-xs h-8"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <Separator className="bg-zinc-700" />

            {/* Submit */}
            <div className="flex gap-2">
              <Button
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                disabled={orderType === 'bundle' ? !selectedBundle : selectedSupplements.length === 0}
              >
                <Pill className="w-4 h-4 mr-2" />
                Create Supplement Plan
              </Button>
              <Button variant="outline" onClick={() => setShowNewOrder(false)} className="border-zinc-700 text-zinc-300">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
