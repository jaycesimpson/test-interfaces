import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { RedactedField } from './RedactedField';
import { MessageSquare, Calendar, FileText, MoreHorizontal } from 'lucide-react';
import type { MemberIdentity } from '@/lib/types';

interface MemberSidebarProps {
  identity: MemberIdentity;
}

export function MemberSidebar({ identity }: MemberSidebarProps) {
  const statusColors = {
    Active: 'bg-green-500/10 text-green-400 border-green-500/20',
    Inactive: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
    Suspended: 'bg-red-500/10 text-red-400 border-red-500/20',
  };

  return (
    <div className="w-[320px] h-screen bg-zinc-900 border-r border-zinc-800 flex flex-col">
      {/* Fixed Header */}
      <div className="p-6 flex-shrink-0">
        <div className="flex flex-col items-center">
          <Avatar className="w-20 h-20 mb-3 border-2 border-zinc-800">
            <AvatarImage src={identity.avatar} alt={identity.name} />
            <AvatarFallback>{identity.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          
          <h2 className="text-xl font-semibold text-zinc-100 mb-1">{identity.name}</h2>
          <p className="text-sm text-zinc-500 mb-2">{identity.id}</p>
          
          <Badge className={statusColors[identity.status]}>
            {identity.status}
          </Badge>
        </div>
      </div>

      <Separator className="bg-zinc-800" />

      {/* Scrollable Content */}
      <ScrollArea className="flex-1 px-6 py-4">
        <div className="space-y-4">
          {/* Redacted Contact Information */}
          <div className="space-y-3">
            <RedactedField
              label="Email"
              value={identity.email}
            />
            
            <RedactedField
              label="Phone"
              value={identity.phone}
            />
            
            <RedactedField
              label="Date of Birth"
              value={new Date(identity.dob).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
            />
          </div>

          <Separator className="bg-zinc-800" />

          {/* Emergency Contact */}
          <div>
            <h3 className="text-xs font-semibold text-zinc-400 mb-3 uppercase tracking-wider">Emergency Contact</h3>
            <RedactedField
              label={identity.emergencyContact.relationship}
              value={`${identity.emergencyContact.name} - ${identity.emergencyContact.phone}`}
            />
          </div>

          <Separator className="bg-zinc-800" />

          {/* Tags */}
          <div>
            <h3 className="text-xs font-semibold text-zinc-400 mb-3 uppercase tracking-wider">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {identity.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-xs border-zinc-700 text-zinc-300">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          {/* Member Since */}
          <div>
            <div className="text-xs text-zinc-500">Member Since</div>
            <div className="text-sm text-zinc-300 mt-1">
              {new Date(identity.memberSince).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </div>
      </ScrollArea>

      {/* Fixed Footer - Quick Actions */}
      <div className="p-4 border-t border-zinc-800 flex-shrink-0 space-y-2">
        <Button className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-100">
          <MessageSquare className="w-4 h-4 mr-2" />
          Send Message
        </Button>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">
            <Calendar className="w-4 h-4 mr-1" />
            Schedule
          </Button>
          <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">
            <FileText className="w-4 h-4 mr-1" />
            Report
          </Button>
        </div>
        <Button variant="outline" className="w-full border-zinc-700 text-zinc-300 hover:bg-zinc-800">
          <MoreHorizontal className="w-4 h-4 mr-2" />
          More Actions
        </Button>
      </div>
    </div>
  );
}
